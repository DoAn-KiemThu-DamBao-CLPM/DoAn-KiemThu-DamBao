<?php
// Secure session settings — must be set before session_start()
ini_set('session.cookie_httponly', '1');
ini_set('session.cookie_samesite', 'Lax');
// Uncomment the line below when your site runs on HTTPS:
// ini_set('session.cookie_secure', '1');
ini_set('session.use_strict_mode', '1');
ini_set('session.use_only_cookies', '1');
ini_set('session.cookie_lifetime', '0');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../includes/csrf.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/content_filter.php';
require_once __DIR__ . '/../includes/schema.php';

// 'development' (XAMPP): password-reset links are shown on screen because no mail server exists.
// Set to 'production' when deploying — links are then only sent by e-mail.
if (!defined('APP_ENV')) {
    define('APP_ENV', 'development');
}

// Basic security headers
if (!headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header("Content-Security-Policy: frame-ancestors 'self'; base-uri 'self'; object-src 'none'; form-action 'self'");
}

// ==========================================
// FILE: config/database.php
// Kết nối đến MySQL bằng PDO
// ==========================================
$host    = '127.0.0.1';
$db      = 'anyn';
$user    = 'root';    // Đổi thành DB user thực khi deploy
$pass    = '';        // Đổi thành DB password thực khi deploy
$charset = 'utf8mb4';

$dsn     = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    // In production, log the error instead of displaying it
    error_log('DB connection failed: ' . $e->getMessage());
    http_response_code(503);
    die('<div style="font-family:sans-serif;text-align:center;padding:80px;"><h2>Service temporarily unavailable</h2><p>Please try again later.</p></div>');
}

// Schema migration (once per session), then global CSRF protection for every POST
try {
    ensureCoreSchema($pdo);
} catch (Throwable $e) {
    error_log('ensureCoreSchema failed: ' . $e->getMessage());
}
csrf_enforce_global();
ob_start('csrf_inject_forms');
