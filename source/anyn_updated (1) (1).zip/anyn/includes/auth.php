<?php
/**
 * Authentication & authorization helpers (Guest / User / Admin).
 *
 * Role lives in users.role ('user' | 'admin'); a visitor without a session is a guest.
 * Replaces the old hard-coded `user_id === 1` checks scattered over the project.
 */

function isLoggedIn(): bool
{
    return !empty($_SESSION['user_id']);
}

function currentUserId(): int
{
    return (int)($_SESSION['user_id'] ?? 0);
}

/**
 * 'guest' | 'user' | 'admin'. The role is re-read from the DB once per request,
 * so demoting an admin takes effect immediately instead of at next login.
 */
function currentRole(): string
{
    static $cache = null;
    if (!isLoggedIn()) {
        return 'guest';
    }
    if ($cache !== null) {
        return $cache;
    }
    global $pdo;
    $role = 'user';
    try {
        $st = $pdo->prepare('SELECT role FROM users WHERE id = ?');
        $st->execute([currentUserId()]);
        $row = $st->fetch();
        if ($row === false) {          // account was deleted → kill session
            $_SESSION = [];
            return $cache = 'guest';
        }
        $role = ($row['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
    } catch (Throwable $e) {
        // Schema not migrated yet: fall back to the legacy rule (first account = admin)
        $role = currentUserId() === 1 ? 'admin' : 'user';
    }
    $_SESSION['role'] = $role;
    return $cache = $role;
}

function isAdmin(): bool
{
    return currentRole() === 'admin';
}

function requireLogin(string $redirect = '/anyn/pages/login.php'): void
{
    if (!isLoggedIn()) {
        header('Location: ' . $redirect);
        exit;
    }
}

function requireAdmin(): void
{
    if (!isAdmin()) {
        http_response_code(403);
        die("<h3 style='color:#ef4444;text-align:center;margin-top:50px;font-family:sans-serif;'>Access Denied! Admin privileges required.</h3>");
    }
}

/**
 * Start an authenticated session. Regenerating the id prevents session fixation.
 */
function loginUser(array $user): void
{
    session_regenerate_id(true);
    $_SESSION['user_id']  = (int)$user['id'];
    $_SESSION['username'] = $user['username'];
    $_SESSION['role']     = ($user['role'] ?? 'user') === 'admin' ? 'admin' : 'user';
    unset($_SESSION['csrf_token']);    // fresh token for the new session
}

function clientIp(): string
{
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? '0.0.0.0'), 0, 45);
}

/* ---------- brute-force protection ---------- */

const LOGIN_MAX_PER_EMAIL = 5;
const LOGIN_MAX_PER_IP    = 20;
const LOGIN_WINDOW_MIN    = 15;

function loginIsThrottled(PDO $pdo, string $email): bool
{
    $pdo->exec('DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 1 DAY)');
    $st = $pdo->prepare(
        'SELECT
            SUM(email = ?) AS by_email,
            COUNT(*)       AS by_ip
         FROM login_attempts
         WHERE ip = ? AND attempted_at > (NOW() - INTERVAL ' . LOGIN_WINDOW_MIN . ' MINUTE)'
    );
    $st->execute([mb_strtolower($email), clientIp()]);
    $r = $st->fetch();
    // Count per-email across all IPs too (distributed guessing)
    $st2 = $pdo->prepare(
        'SELECT COUNT(*) FROM login_attempts
         WHERE email = ? AND attempted_at > (NOW() - INTERVAL ' . LOGIN_WINDOW_MIN . ' MINUTE)'
    );
    $st2->execute([mb_strtolower($email)]);
    return (int)$st2->fetchColumn() >= LOGIN_MAX_PER_EMAIL
        || (int)($r['by_ip'] ?? 0) >= LOGIN_MAX_PER_IP;
}

function loginRecordFailure(PDO $pdo, string $email): void
{
    $pdo->prepare('INSERT INTO login_attempts (ip, email) VALUES (?, ?)')
        ->execute([clientIp(), mb_strtolower(mb_substr($email, 0, 255))]);
}

function loginClearFailures(PDO $pdo, string $email): void
{
    $pdo->prepare('DELETE FROM login_attempts WHERE email = ?')->execute([mb_strtolower($email)]);
}

/* ---------- shared validation ---------- */

function validateUsername(string $u): ?string
{
    if (mb_strlen($u) < 3 || mb_strlen($u) > 30) {
        return 'Username must be 3–30 characters.';
    }
    if (!preg_match('/^[\p{L}\p{N}_. -]+$/u', $u)) {
        return 'Username may only contain letters, numbers, spaces, dots, dashes and underscores.';
    }
    return null;
}

function validatePassword(string $p): ?string
{
    if (strlen($p) < 8) {
        return 'Password must be at least 8 characters.';
    }
    if (strlen($p) > 72) {            // bcrypt only uses the first 72 bytes
        return 'Password must be at most 72 characters.';
    }
    if (!preg_match('/[A-Za-z]/', $p) || !preg_match('/\d/', $p)) {
        return 'Password must contain at least one letter and one number.';
    }
    return null;
}
