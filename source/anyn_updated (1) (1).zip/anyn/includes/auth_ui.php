<?php
/**
 * Minimal split-screen layout shared by forgot/reset password pages
 * (same look as login.php / register.php).
 */

function authPageStart(string $title, string $heading, string $sub): void
{
    ?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="color-scheme" content="light dark">
<?php require __DIR__ . '/theme_early.php'; ?>
    <title><?= htmlspecialchars($title) ?> — Anyn</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Playfair+Display:wght@600;700&display=swap" rel="stylesheet">
    <style>
        :root { --pink:#ffb7c5; --pink-dark:#ff7f9e; --pink-soft:#fff0f4; --bg:#faf8f9; --surface:#fff; --border:#f0ecee; --text:#2d2730; --text-2:#7a6e72; --text-3:#b0a8ac; }
        [data-theme="dark"] { --bg:#131015; --surface:#1d191f; --border:#332d36; --text:#f0eaed; --text-2:#a099a3; --text-3:#5c5560; --pink-soft:#2a1d22; }
        *, *::before, *::after { box-sizing:border-box; margin:0; padding:0; }
        a { text-decoration:none; }
        body { font-family:'DM Sans',sans-serif; background:var(--bg); color:var(--text); min-height:100vh; display:flex; align-items:stretch; }
        .auth-left { flex:1; background:linear-gradient(160deg,#ff8fa3 0%,#ffb7c5 50%,#ffd6e0 100%); display:flex; flex-direction:column; align-items:center; justify-content:center; padding:60px 40px; position:relative; }
        .auth-left-logo { font-family:'Playfair Display',serif; font-size:48px; font-weight:700; color:#fff; margin-bottom:16px; text-shadow:0 4px 20px rgba(0,0,0,.15); }
        .auth-left-tagline { color:rgba(255,255,255,.85); font-size:16px; text-align:center; max-width:280px; line-height:1.65; }
        .auth-right { width:480px; flex-shrink:0; background:var(--surface); display:flex; align-items:center; justify-content:center; padding:60px 50px; }
        .auth-form { width:100%; max-width:360px; }
        .auth-heading { font-family:'Playfair Display',serif; font-size:30px; margin-bottom:8px; }
        .auth-sub { color:var(--text-3); font-size:14px; margin-bottom:28px; line-height:1.5; }
        .form-group { margin-bottom:16px; }
        .form-group label { display:block; font-size:12px; font-weight:700; letter-spacing:.5px; text-transform:uppercase; color:var(--text-2); margin-bottom:7px; }
        .input-wrap { position:relative; }
        .input-wrap i.icon-l { position:absolute; left:14px; top:50%; transform:translateY(-50%); color:var(--text-3); font-size:14px; }
        .input-wrap input { width:100%; padding:12px 14px 12px 40px; background:var(--bg); border:1.5px solid var(--border); border-radius:12px; font-size:14px; font-family:inherit; color:var(--text); outline:none; }
        .input-wrap input:focus { border-color:var(--pink-dark); box-shadow:0 0 0 3px rgba(255,183,197,.2); }
        .btn-submit { width:100%; background:linear-gradient(135deg,var(--pink),var(--pink-dark)); color:#fff; border:none; padding:14px; border-radius:12px; font-size:15px; font-weight:700; font-family:inherit; cursor:pointer; }
        .back-row { text-align:center; font-size:14px; color:var(--text-3); margin-top:22px; }
        .back-row a { color:var(--pink-dark); font-weight:700; }
        .error-box,.success-box,.info-box { padding:11px 15px; border-radius:10px; font-size:13px; font-weight:500; margin-bottom:20px; border:1px solid; display:flex; gap:8px; align-items:flex-start; word-break:break-word; }
        .error-box { background:#fef2f2; color:#dc2626; border-color:#fca5a5; }
        .success-box { background:#f0fdf4; color:#16a34a; border-color:#86efac; }
        .info-box { background:#fffbeb; color:#92400e; border-color:#fcd34d; }
        @media (max-width:860px) { .auth-left { display:none; } .auth-right { width:100%; padding:40px 24px; } }
        @media (max-width:768px) { input { font-size:16px !important; } }
    </style>
</head>
<body>
    <div class="auth-left">
        <a href="../index.php" style="position:absolute;top:28px;left:32px;color:rgba(255,255,255,.75);font-size:13px;font-weight:600;display:flex;align-items:center;gap:6px;">
            <i class="fa-solid fa-arrow-left"></i> Back to Store
        </a>
        <div class="auth-left-logo">Anyn</div>
        <p class="auth-left-tagline">Your gateway to hundreds of unique roleplay characters.</p>
    </div>
    <div class="auth-right">
        <div class="auth-form">
            <h1 class="auth-heading"><?= htmlspecialchars($heading) ?></h1>
            <p class="auth-sub"><?= htmlspecialchars($sub) ?></p>
<?php
}

function authPageEnd(): void
{
    ?>
        </div>
    </div>
</body>
</html>
<?php
}

/** Base URL of this site (…/anyn/pages), safe against Host-header injection. */
function appBaseUrl(): string
{
    if (defined('APP_URL') && APP_URL !== '') {
        return rtrim(APP_URL, '/');
    }
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    if (!preg_match('/^[A-Za-z0-9.\-]+(:\d{1,5})?$/', $host)) {
        $host = 'localhost';
    }
    $https  = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    $dir    = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'] ?? '/anyn/pages/x.php')), '/');
    return ($https ? 'https://' : 'http://') . $host . $dir;
}
