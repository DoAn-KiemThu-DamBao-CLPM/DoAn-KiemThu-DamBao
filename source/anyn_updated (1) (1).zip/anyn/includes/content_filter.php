<?php
/**
 * Content policy: NSFW / explicit tags are not allowed on this site.
 *
 * Names are compared after normalising (lower-case, letters+digits only), so
 * "Net-ori", "NETORI" and "netori " all match. Add more entries here if needed.
 */

function blockedThemeKeys(): array
{
    return [
        // netori / cheating family
        'netori', 'netorare', 'netora', 'ntr', 'cheating', 'cheater', 'cheat',
        'cuck', 'cuckold', 'cuckquean', 'infidelity', 'adultery',
        // generic explicit markers
        'nsfw', 'r18', 'r18g', '18', 'hentai', 'smut', 'lewd', 'erotic', 'erotica',
        'porn', 'sex', 'sexual', 'bdsm', 'fetish',
        // non-consensual / minors-related
        'rape', 'noncon', 'dubcon', 'cnc', 'consensualnonconsent', 'incest', 'loli', 'shota',
        // family-taboo tags
        'stepfamily',
    ];
}

function normalizeThemeName(string $name): string
{
    return preg_replace('/[^a-z0-9]+/', '', mb_strtolower($name));
}

function isBlockedTheme(string $name): bool
{
    return in_array(normalizeThemeName($name), blockedThemeKeys(), true);
}

/** Remove blocked names from a list of tag names (keeps order, re-indexes). */
function filterThemeNames(array $names): array
{
    return array_values(array_filter($names, fn($n) => !isBlockedTheme((string)$n)));
}

/** Split a GROUP_CONCAT string of tags and drop blocked ones. */
function visibleThemeNames(?string $csv): array
{
    if ($csv === null || trim($csv) === '') {
        return [];
    }
    return filterThemeNames(array_map('trim', explode(',', $csv)));
}

/**
 * Delete blocked tags (and their links to bots) from the database.
 * Safe to call repeatedly. Returns the number of tags removed.
 */
function purgeBlockedThemes(PDO $pdo): int
{
    $ids = [];
    foreach ($pdo->query('SELECT id, name FROM themes')->fetchAll() as $t) {
        if (isBlockedTheme($t['name'])) {
            $ids[] = (int)$t['id'];
        }
    }
    if (!$ids) {
        return 0;
    }
    $in = implode(',', array_fill(0, count($ids), '?'));
    $pdo->prepare("DELETE FROM bot_themes WHERE theme_id IN ($in)")->execute($ids);
    $pdo->prepare("DELETE FROM themes WHERE id IN ($in)")->execute($ids);
    return count($ids);
}
