<?php
/**
 * CSRF Protection Helper
 * Include this file and call csrf_verify() at the top of every POST handler.
 */

/**
 * Get (or generate) the CSRF token for this session.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Return an HTML hidden input with the CSRF token.
 * Usage: <?= csrf_field() ?> inside every <form>.
 */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="'
        . htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8')
        . '">';
}

/**
 * Verify the CSRF token submitted in $_POST.
 * Halts execution with 403 if invalid.
 */
function csrf_verify(): void
{
    $submitted = $_POST['csrf_token'] ?? '';
    if (!hash_equals(csrf_token(), $submitted)) {
        http_response_code(403);
        die(
            '<div style="font-family:sans-serif;text-align:center;padding:80px 20px;">'
            . '<h2 style="color:#ef4444;">Security Error</h2>'
            . '<p style="color:#6b7280;">Invalid or expired security token. Please go back and try again.</p>'
            . '<a href="javascript:history.back()" style="color:#ff7f9e;font-weight:600;">Go back</a>'
            . '</div>'
        );
    }
}

/**
 * Validate that an uploaded file is a real image using MIME type (not just extension).
 * Returns cleaned extension on success, null on failure.
 */
function validate_image_upload(array $file, int $max_bytes = 10485760): ?string
{
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    if ((int)$file['size'] > $max_bytes) {
        return null;
    }

    // Check real MIME type from file content
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime  = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowed_mimes = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/gif'  => 'gif',
        'image/webp' => 'webp',
    ];

    return $allowed_mimes[$mime] ?? null;
}

/**
 * Global CSRF guard: every POST request must carry a valid token.
 * Called once from config/database.php so no page can forget it.
 */
function csrf_enforce_global(): void
{
    if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST') {
        csrf_verify();
    }
}

/**
 * Accept only absolute http(s) URLs (max 500 chars). Returns null when invalid.
 * Use for any user/admin supplied image or link URL before it is stored.
 */
function safe_http_url(?string $url, int $max = 500): ?string
{
    $url = trim((string)$url);
    if ($url === '' || strlen($url) > $max) {
        return null;
    }
    if (!filter_var($url, FILTER_VALIDATE_URL)) {
        return null;
    }
    $scheme = strtolower((string)parse_url($url, PHP_URL_SCHEME));
    return in_array($scheme, ['http', 'https'], true) ? $url : null;
}

/**
 * Trim + cut a string to a maximum number of characters (UTF-8 safe).
 */
function clean_text($value, int $max): string
{
    $value = trim((string)$value);
    return mb_strlen($value) > $max ? mb_substr($value, 0, $max) : $value;
}

/**
 * Escape % and _ so user input is matched literally inside a LIKE pattern.
 */
function like_escape(string $s): string
{
    return str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $s);
}

/**
 * Output-buffer callback: adds the CSRF hidden input to every <form method="post">
 * that does not already contain one, so new/old forms are protected automatically.
 */
function csrf_inject_forms(string $html): string
{
    if (stripos($html, '<form') === false) {
        return $html;
    }
    $field = csrf_field();
    return preg_replace_callback('/<form\b[^>]*>.*?<\/form>/is', function ($m) use ($field) {
        $block = $m[0];
        if (stripos($block, 'name="csrf_token"') !== false) {
            return $block;
        }
        if (!preg_match('/^<form\b[^>]*\bmethod\s*=\s*["\']?post/i', $block)) {
            return $block;
        }
        return preg_replace('/^(<form\b[^>]*>)/i', '$1' . $field, $block, 1);
    }, $html) ?? $html;
}
