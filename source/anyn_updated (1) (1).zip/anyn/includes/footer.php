</div> <!-- Đóng thẻ div class="container" ở file header -->
<?php if (!defined('ANYN_DISCORD_URL')) { require_once __DIR__ . '/site_links.php'; } ?>

<footer class="site-footer">
    <span style="color:var(--text-3);font-size:13px;">© <?= date('Y') ?> ANYN</span>
    <a href="<?= ANYN_DISCORD_URL ?>" class="discord-pill" target="_blank" rel="noopener noreferrer">
        <i class="fa-brands fa-discord" style="font-size:16px;color:#5865F2;"></i>
        Join our Discord
    </a>
</footer>

<script>
/* Keep the scroll position when a link/form reloads the SAME page (sort, filters, tabs, like, comment...).
   Add data-scroll-top to a link/form if it should jump to the top instead (e.g. pagination). */
(function () {
    var KEY = 'anynScroll';
    function save() {
        try {
            sessionStorage.setItem(KEY, JSON.stringify({
                path: location.pathname,
                y: window.pageYOffset || document.documentElement.scrollTop || 0,
                t: Date.now()
            }));
        } catch (e) {}
    }
    function restore() {
        var d;
        try { d = JSON.parse(sessionStorage.getItem(KEY) || 'null'); } catch (e) { d = null; }
        if (!d || d.path !== location.pathname || Date.now() - d.t > 15000 || location.hash) return null;
        window.scrollTo({ top: d.y, left: 0, behavior: 'instant' });
        return d;
    }
    if ('scrollRestoration' in history) history.scrollRestoration = 'manual';

    var saved = restore();
    if (saved) {
        // images/fonts may still change the page height: apply once more after full load
        window.addEventListener('load', function () {
            window.scrollTo({ top: saved.y, left: 0, behavior: 'instant' });
            try { sessionStorage.removeItem(KEY); } catch (e) {}
        });
    } else {
        try { sessionStorage.removeItem(KEY); } catch (e) {}
    }

    document.addEventListener('click', function (e) {
        var a = e.target.closest ? e.target.closest('a[href]') : null;
        if (!a || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        if (a.target === '_blank' || a.hasAttribute('download') || a.hasAttribute('data-scroll-top')) return;
        var url;
        try { url = new URL(a.href, location.href); } catch (err) { return; }
        if (url.origin === location.origin && url.pathname === location.pathname && !url.hash) save();
    });
    document.addEventListener('submit', function (e) {
        var f = e.target;
        if (f && f.tagName === 'FORM' && !f.hasAttribute('data-scroll-top')) save();
    });
})();
</script>
</body>
</html>
