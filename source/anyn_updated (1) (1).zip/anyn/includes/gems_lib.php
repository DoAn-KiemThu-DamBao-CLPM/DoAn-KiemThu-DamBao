<?php

function ensureGemsSchema(PDO $pdo): void
{
    if (!$pdo->query("SHOW COLUMNS FROM users LIKE 'gems'")->fetch()) {
        $pdo->exec('ALTER TABLE users ADD COLUMN gems INT(11) NOT NULL DEFAULT 0 AFTER total_spent');
    }
    if (!$pdo->query("SHOW COLUMNS FROM users LIKE 'active_avatar_frame'")->fetch()) {
        $pdo->exec('ALTER TABLE users ADD COLUMN active_avatar_frame VARCHAR(50) NULL');
    }

    $pdo->exec("CREATE TABLE IF NOT EXISTS shop_items (
        id INT AUTO_INCREMENT PRIMARY KEY,
        item_key VARCHAR(80) NOT NULL UNIQUE,
        name VARCHAR(120) NOT NULL,
        category VARCHAR(40) NOT NULL,
        cost_gems INT(11) NOT NULL,
        description VARCHAR(255) NULL,
        meta_json TEXT NULL,
        sort_order INT NOT NULL DEFAULT 0,
        is_active TINYINT(1) NOT NULL DEFAULT 1
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS user_inventory (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NOT NULL,
        item_key VARCHAR(80) NOT NULL,
        item_type VARCHAR(40) NOT NULL,
        meta_json TEXT NULL,
        used_at TIMESTAMP NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_inv_user (user_id),
        INDEX idx_inv_type (user_id, item_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS gem_mission_log (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NOT NULL,
        mission_key VARCHAR(50) NOT NULL,
        log_date DATE NOT NULL,
        count INT(11) NOT NULL DEFAULT 1,
        UNIQUE KEY uq_mission_day (user_id, mission_key, log_date)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS commission_monthly_limit (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NOT NULL,
        month_year VARCHAR(7) NOT NULL,
        commission_type VARCHAR(20) NOT NULL,
        count INT(11) NOT NULL DEFAULT 0,
        UNIQUE KEY uq_monthly_commission (user_id, month_year, commission_type)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS image_set_requests (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NOT NULL,
        item_key VARCHAR(80) NOT NULL,
        image_url VARCHAR(255) NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'pending',
        admin_link VARCHAR(255) NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NULL DEFAULT NULL,
        INDEX idx_req_user (user_id),
        INDEX idx_req_status (status)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    seedShopItems($pdo);
}

function gemsMissionDefinitions(): array
{
    return [
        'daily_checkin'      => ['name' => 'Daily check-in',           'gems' => 5,  'daily_max' => 1],
        'react_gallery'      => ['name' => 'Like gallery art',         'gems' => 2,  'daily_max' => 10],
        'react_community'    => ['name' => 'React to community art',   'gems' => 2,  'daily_max' => 10],
        'upload_community'   => ['name' => 'Upload community art',     'gems' => 15, 'daily_max' => 2],
        'submit_idea'        => ['name' => 'Submit an idea',           'gems' => 10, 'daily_max' => 3],
        'upvote_idea'        => ['name' => 'Upvote an idea',           'gems' => 1,  'daily_max' => 20],
        'submit_commission'  => ['name' => 'Submit a commission',      'gems' => 25, 'daily_max' => 2],
    ];
}

function seedShopItems(PDO $pdo): void
{
    $items = [
        ['avt_gold', 'Gold Avatar Ring', 'avatar_frame', 25, 'Golden ring around your avatar', '{}', 50],
        ['avt_crystal', 'Crystal Avatar Ring', 'avatar_frame', 45, 'Icy crystal avatar border', '{}', 60],
        ['avt_bloom', 'Bloom Avatar Ring', 'avatar_frame', 60, 'Floral glow avatar frame', '{}', 70],
        ['coupon_commission_publish', 'Commission — Published', 'commission_publish', 200, 'Voucher for a published store commission (use when ordering). Max 1 per month.', '{}', 100],
        ['coupon_commission_unlisted', 'Commission — Unlisted', 'commission_unlisted', 100, 'Voucher for an unlisted commission (use when ordering). Max 3 per month.', '{}', 110],
        ['imageset_60', 'Character image sets — 3', 'image_set', 60, 'Select a character image set (3 gems tier)', '{"images":60}', 200],
        ['imageset_100', 'Character image sets — 5', 'image_set', 100, 'Select a character image set (5 gems tier)', '{"images":100}', 210],
        ['imageset_200', 'Character image sets — 10', 'image_set', 200, 'Select a character image set (10 gems tier)', '{"images":200}', 220],
        ['imageset_600', 'Character image sets — 30', 'image_set', 600, 'Select a character image set (30 gems tier)', '{"images":600,"usd":60}', 250],
    ];

    $stmt = $pdo->prepare('INSERT INTO shop_items (item_key, name, category, cost_gems, description, meta_json, sort_order)
        VALUES (?, ?, ?, ?, ?, ?, ?)
        ON DUPLICATE KEY UPDATE
            name = VALUES(name),
            category = VALUES(category),
            cost_gems = VALUES(cost_gems),
            description = VALUES(description),
            meta_json = VALUES(meta_json),
            sort_order = VALUES(sort_order),
            is_active = 1');
    foreach ($items as $row) {
        $stmt->execute($row);
    }

    // Global Chat was removed: hide the old chat-frame items from the shop.
    // (Rows stay in the DB so existing purchases in user_inventory still resolve a name.)
    $pdo->exec("UPDATE shop_items SET is_active = 0 WHERE category = 'chat_frame'");
}

function getUserGems(PDO $pdo, int $userId): int
{
    $s = $pdo->prepare('SELECT gems FROM users WHERE id = ?');
    $s->execute([$userId]);
    return (int)($s->fetchColumn() ?: 0);
}

function addGems(PDO $pdo, int $userId, int $amount): void
{
    if ($amount <= 0) {
        return;
    }
    $pdo->prepare('UPDATE users SET gems = gems + ? WHERE id = ?')->execute([$amount, $userId]);
}

function spendGems(PDO $pdo, int $userId, int $amount): bool
{
    if ($amount <= 0 || getUserGems($pdo, $userId) < $amount) {
        return false;
    }
    $pdo->prepare('UPDATE users SET gems = gems - ? WHERE id = ?')->execute([$amount, $userId]);
    return true;
}

function tryAwardMission(PDO $pdo, int $userId, string $missionKey): array
{
    $defs = gemsMissionDefinitions();
    if (!isset($defs[$missionKey])) {
        return ['ok' => false, 'gems' => 0, 'message' => 'Unknown mission.'];
    }
    $def = $defs[$missionKey];
    $today = date('Y-m-d');

    $log = $pdo->prepare('SELECT count FROM gem_mission_log WHERE user_id = ? AND mission_key = ? AND log_date = ?');
    $log->execute([$userId, $missionKey, $today]);
    $row = $log->fetch();
    $current = $row ? (int)$row['count'] : 0;

    if ($current >= $def['daily_max']) {
        return ['ok' => false, 'gems' => 0, 'message' => 'Daily limit reached for this mission.'];
    }

    if ($row) {
        $pdo->prepare('UPDATE gem_mission_log SET count = count + 1 WHERE user_id = ? AND mission_key = ? AND log_date = ?')
            ->execute([$userId, $missionKey, $today]);
    } else {
        $pdo->prepare('INSERT INTO gem_mission_log (user_id, mission_key, log_date, count) VALUES (?, ?, ?, 1)')
            ->execute([$userId, $missionKey, $today]);
    }

    addGems($pdo, $userId, $def['gems']);
    return [
        'ok'      => true,
        'gems'    => $def['gems'],
        'message' => '+' . $def['gems'] . ' gems — ' . $def['name'],
    ];
}

function getMissionProgress(PDO $pdo, int $userId): array
{
    $today = date('Y-m-d');
    $out = [];
    foreach (gemsMissionDefinitions() as $key => $def) {
        $log = $pdo->prepare('SELECT count FROM gem_mission_log WHERE user_id = ? AND mission_key = ? AND log_date = ?');
        $log->execute([$userId, $key, $today]);
        $done = (int)($log->fetchColumn() ?: 0);
        $out[$key] = [
            'name'      => $def['name'],
            'gems'      => $def['gems'],
            'daily_max' => $def['daily_max'],
            'done'      => $done,
        ];
    }
    return $out;
}

function getShopItems(PDO $pdo, ?string $category = null): array
{
    if ($category) {
        $s = $pdo->prepare('SELECT * FROM shop_items WHERE is_active = 1 AND category = ? ORDER BY sort_order, cost_gems');
        $s->execute([$category]);
        return $s->fetchAll();
    }
    return $pdo->query('SELECT * FROM shop_items WHERE is_active = 1 ORDER BY sort_order, cost_gems')->fetchAll();
}

function getShopItem(PDO $pdo, string $itemKey): ?array
{
    $s = $pdo->prepare('SELECT * FROM shop_items WHERE item_key = ? AND is_active = 1');
    $s->execute([$itemKey]);
    $row = $s->fetch();
    return $row ?: null;
}

function userOwnsItem(PDO $pdo, int $userId, string $itemKey): bool
{
    $s = $pdo->prepare('SELECT id FROM user_inventory WHERE user_id = ? AND item_key = ? AND used_at IS NULL LIMIT 1');
    $s->execute([$userId, $itemKey]);
    return (bool)$s->fetch();
}

function countUnusedInventory(PDO $pdo, int $userId, string $itemType): int
{
    $s = $pdo->prepare('SELECT COUNT(*) FROM user_inventory WHERE user_id = ? AND item_type = ? AND used_at IS NULL');
    $s->execute([$userId, $itemType]);
    return (int)$s->fetchColumn();
}

function purchaseShopItem(PDO $pdo, int $userId, string $itemKey): array
{
    $item = getShopItem($pdo, $itemKey);
    if (!$item) {
        return ['ok' => false, 'message' => 'Item not found.'];
    }

    $cosmeticTypes = ['avatar_frame'];
    if (in_array($item['category'], $cosmeticTypes, true) && userOwnsItem($pdo, $userId, $itemKey)) {
        return ['ok' => false, 'message' => 'You already own this cosmetic.'];
    }

    // Check monthly limit for commission vouchers
    if (in_array($item['category'], ['commission_publish', 'commission_unlisted'], true)) {
        $limitCheck = canUseCommissionVoucher($pdo, $item['category']);
        if (!$limitCheck['ok']) {
            return ['ok' => false, 'message' => $limitCheck['message']];
        }
    }

    if (!spendGems($pdo, $userId, (int)$item['cost_gems'])) {
        return ['ok' => false, 'message' => 'Not enough gems.'];
    }

    $pdo->prepare('INSERT INTO user_inventory (user_id, item_key, item_type, meta_json) VALUES (?, ?, ?, ?)')
        ->execute([$userId, $itemKey, $item['category'], $item['meta_json']]);

    // Track monthly commission purchase
    if (in_array($item['category'], ['commission_publish', 'commission_unlisted'], true)) {
        incrementMonthlyCommissionCount($pdo, $userId, $item['category']);
    }

    if ($item['category'] === 'avatar_frame') {
        $pdo->prepare('UPDATE users SET active_avatar_frame = ? WHERE id = ?')->execute([$itemKey, $userId]);
    }

    return ['ok' => true, 'message' => 'Purchased: ' . $item['name']];
}

function equipCosmetic(PDO $pdo, int $userId, string $type, ?string $itemKey): array
{
    if ($type === 'avatar_frame') {
        if ($itemKey && !userOwnsItem($pdo, $userId, $itemKey)) {
            return ['ok' => false, 'message' => 'You do not own this frame.'];
        }
        $pdo->prepare('UPDATE users SET active_avatar_frame = ? WHERE id = ?')->execute([$itemKey, $userId]);
        return ['ok' => true, 'message' => $itemKey ? 'Avatar frame equipped.' : 'Avatar frame removed.'];
    }
    return ['ok' => false, 'message' => 'Invalid type.'];
}

function consumeInventoryCoupon(PDO $pdo, int $userId, string $itemType): ?int
{
    $s = $pdo->prepare('SELECT id FROM user_inventory WHERE user_id = ? AND item_type = ? AND used_at IS NULL ORDER BY id ASC LIMIT 1');
    $s->execute([$userId, $itemType]);
    $row = $s->fetch();
    if (!$row) {
        return null;
    }
    $pdo->prepare('UPDATE user_inventory SET used_at = NOW() WHERE id = ?')->execute([$row['id']]);
    return (int)$row['id'];
}

function getMonthlyCommissionCount(PDO $pdo, string $commissionType): int
{
    $monthYear = date('Y-m');
    // Đã thay đổi: Dùng SUM(count) thay vì COUNT(*) để tính chính xác khi có duplicate
    $s = $pdo->prepare('SELECT SUM(count) FROM commission_monthly_limit WHERE month_year = ? AND commission_type = ?');
    $s->execute([$monthYear, $commissionType]);
    return (int)($s->fetchColumn() ?: 0);
}

function incrementMonthlyCommissionCount(PDO $pdo, int $userId, string $commissionType): void
{
    $monthYear = date('Y-m');
    // Đã thay đổi: Thêm ON DUPLICATE KEY UPDATE để giải quyết lỗi 1062
    $pdo->prepare('INSERT INTO commission_monthly_limit (user_id, month_year, commission_type, count) 
                   VALUES (?, ?, ?, 1) 
                   ON DUPLICATE KEY UPDATE count = count + 1')
        ->execute([$userId, $monthYear, $commissionType]);
}

function canUseCommissionVoucher(PDO $pdo, string $commissionType): array
{
    $limits = [
        'commission_publish' => 1,
        'commission_unlisted' => 3
    ];
    
    if (!isset($limits[$commissionType])) {
        return ['ok' => false, 'message' => 'Invalid commission type.'];
    }
    
    $currentCount = getMonthlyCommissionCount($pdo, $commissionType);
    $maxLimit = $limits[$commissionType];
    
    if ($currentCount >= $maxLimit) {
        return ['ok' => false, 'message' => "Monthly limit reached ({$maxLimit} per month for the entire shop)."];
    }
    
    return ['ok' => true];
}

function getRemainingCommissionLimit(PDO $pdo, string $commissionType): int
{
    $limits = [
        'commission_publish' => 1,
        'commission_unlisted' => 3
    ];
    
    if (!isset($limits[$commissionType])) {
        return 0;
    }
    
    $currentCount = getMonthlyCommissionCount($pdo, $commissionType);
    $maxLimit = $limits[$commissionType];
    
    return max(0, $maxLimit - $currentCount);
}

function createImageSetRequest(PDO $pdo, int $userId, string $itemKey, string $imageUrl): array
{
    $item = getShopItem($pdo, $itemKey);
    if (!$item || $item['category'] !== 'image_set') {
        return ['ok' => false, 'message' => 'Invalid image set item.'];
    }

    if (!spendGems($pdo, $userId, (int)$item['cost_gems'])) {
        return ['ok' => false, 'message' => 'Not enough gems.'];
    }

    $stmt = $pdo->prepare('INSERT INTO image_set_requests (user_id, item_key, image_url, status) VALUES (?, ?, ?, ?)');
    $stmt->execute([$userId, $itemKey, $imageUrl, 'pending']);

    return ['ok' => true, 'message' => 'Image set request submitted. Admin will send you the link soon.'];
}

function getUserImageSetRequests(PDO $pdo, int $userId): array
{
    $s = $pdo->prepare('SELECT isr.*, si.name as item_name, si.cost_gems FROM image_set_requests isr LEFT JOIN shop_items si ON isr.item_key = si.item_key WHERE isr.user_id = ? ORDER BY isr.created_at DESC');
    $s->execute([$userId]);
    return $s->fetchAll();
}

function getUserInventory(PDO $pdo, int $userId, ?string $type = null): array
{
    if ($type) {
        $s = $pdo->prepare('SELECT ui.*, si.name FROM user_inventory ui LEFT JOIN shop_items si ON ui.item_key = si.item_key WHERE ui.user_id = ? AND ui.item_type = ? ORDER BY ui.created_at DESC');
        $s->execute([$userId, $type]);
        return $s->fetchAll();
    }
    $s = $pdo->prepare('SELECT ui.*, si.name FROM user_inventory ui LEFT JOIN shop_items si ON ui.item_key = si.item_key WHERE ui.user_id = ? ORDER BY ui.created_at DESC');
    $s->execute([$userId]);
    return $s->fetchAll();
}

function shopCategoryLabel(string $cat): string
{
    return match ($cat) {
        'avatar_frame'         => 'Avatar frames',
        'commission_publish'   => 'Commission vouchers',
        'commission_unlisted'  => 'Commission vouchers',
        'image_set'            => 'Character image sets',
        default                => ucfirst(str_replace('_', ' ', $cat)),
    };
}