<?php
/**
 * Auto-migration for the features added in the security/accounts update.
 * Same style as gems_lib.php / ideas_lib.php: idempotent, runs once per session.
 * The equivalent plain SQL is in sql/accounts_security.sql (run it in phpMyAdmin if you prefer).
 */

function schemaColumnExists(PDO $pdo, string $table, string $column): bool
{
    $st = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS
         WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?'
    );
    $st->execute([$table, $column]);
    return (int)$st->fetchColumn() > 0;
}

function schemaTableExists(PDO $pdo, string $table): bool
{
    $st = $pdo->prepare(
        'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?'
    );
    $st->execute([$table]);
    return (int)$st->fetchColumn() > 0;
}

function ensureCoreSchema(PDO $pdo): void
{
    if (($_SESSION['schema_ok'] ?? 0) === 4) {
        return;
    }

    // ---- users: role (RBAC), bio ----
    if (!schemaColumnExists($pdo, 'users', 'role')) {
        $pdo->exec("ALTER TABLE users ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user'");
        $pdo->exec("UPDATE users SET role = 'admin' WHERE id = 1");   // keep the old admin
    }
    if (!schemaColumnExists($pdo, 'users', 'bio')) {
        $pdo->exec('ALTER TABLE users ADD COLUMN bio VARCHAR(255) NULL');
    }

    // ---- unique email / username (stops duplicate accounts at DB level) ----
    foreach (['username', 'email'] as $col) {
        $has = $pdo->prepare(
            'SELECT COUNT(*) FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \'users\' AND COLUMN_NAME = ? AND NON_UNIQUE = 0'
        );
        $has->execute([$col]);
        if ((int)$has->fetchColumn() === 0) {
            try {
                $pdo->exec("ALTER TABLE users ADD UNIQUE KEY uq_users_$col ($col)");
            } catch (PDOException $e) {
                error_log("Could not add unique index on users.$col (duplicates exist?): " . $e->getMessage());
            }
        }
    }

    // ---- comments: edited marker ----
    if (!schemaColumnExists($pdo, 'comments', 'edited_at')) {
        $pdo->exec('ALTER TABLE comments ADD COLUMN edited_at TIMESTAMP NULL DEFAULT NULL');
    }

    // ---- password reset tokens (only the SHA-256 hash is stored) ----
    $pdo->exec("CREATE TABLE IF NOT EXISTS password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT(11) NOT NULL,
        token_hash CHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        used_at DATETIME NULL DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_reset_token (token_hash),
        INDEX idx_reset_user (user_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // ---- login throttling ----
    $pdo->exec("CREATE TABLE IF NOT EXISTS login_attempts (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ip VARCHAR(45) NOT NULL,
        email VARCHAR(255) NOT NULL,
        attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_la_ip (ip, attempted_at),
        INDEX idx_la_email (email, attempted_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // ---- follow system ----
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_follows (
        follower_id INT(11) NOT NULL,
        following_id INT(11) NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (follower_id, following_id),
        INDEX idx_follow_following (following_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // ---- content policy: remove NSFW tags (netori, cheating, ...) ----
    require_once __DIR__ . '/content_filter.php';
    try {
        purgeBlockedThemes($pdo);
    } catch (PDOException $e) {
        error_log('purgeBlockedThemes failed: ' . $e->getMessage());
    }

    $_SESSION['schema_ok'] = 4;
}
