<?php
require_once 'config/database.php';
require_once 'includes/header.php';

function safeCount(PDO $pdo, string $sql, array $params = []): int {
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return (int)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

$search = clean_text($_GET['search'] ?? '', 100);
$theme  = clean_text($_GET['theme']  ?? '', 60);
if ($theme !== '' && isBlockedTheme($theme)) { $theme = ''; }

$sort_options = [
    'new'    => ['Newest',    'b.is_pinned DESC, b.created_at DESC'],
    'rating' => ['Top rated', 'b.total_rating DESC, b.created_at DESC'],
    'name'   => ['A → Z',     'b.name ASC'],
];
$sort = $_GET['sort'] ?? 'new';
if (!isset($sort_options[$sort])) { $sort = 'new'; }

$per_page = 24;
$page     = max(1, (int)($_GET['page'] ?? 1));

$where  = ' WHERE 1=1 ';
$params = [];
if ($search !== '') {
    $where .= " AND (b.name LIKE ? OR b.description LIKE ?) ";
    $like = '%' . like_escape($search) . '%';
    $params[] = $like; $params[] = $like;
}
if ($theme !== '') {
    $where .= " AND b.id IN (SELECT bt2.bot_id FROM bot_themes bt2 JOIN themes t2 ON bt2.theme_id = t2.id WHERE t2.name = ?) ";
    $params[] = $theme;
}

$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM bots b $where");
$count_stmt->execute($params);
$filtered_total = (int)$count_stmt->fetchColumn();
$total_pages    = max(1, (int)ceil($filtered_total / $per_page));
$page           = min($page, $total_pages);
$offset         = ($page - 1) * $per_page;

$sql = "SELECT b.*, GROUP_CONCAT(t.name SEPARATOR ',') as theme_names
        FROM bots b
        LEFT JOIN bot_themes bt ON b.id = bt.bot_id
        LEFT JOIN themes t ON bt.theme_id = t.id
        $where
        GROUP BY b.id ORDER BY " . $sort_options[$sort][1] . " LIMIT $per_page OFFSET $offset";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$bots = $stmt->fetchAll();

$all_themes = filterThemeNames($pdo->query("SELECT name FROM themes ORDER BY name ASC")->fetchAll(PDO::FETCH_COLUMN));

/** Build a home-page URL keeping the active filters. */
function homeUrl(array $over = []): string {
    global $search, $theme, $sort, $page;
    $q = array_merge(['search' => $search, 'theme' => $theme, 'sort' => $sort, 'page' => $page], $over);
    if (($q['sort'] ?? 'new') === 'new') { unset($q['sort']); }
    if (($q['page'] ?? 1) <= 1) { unset($q['page']); }
    $q = array_filter($q, fn($v) => $v !== '' && $v !== null);
    return 'index.php' . ($q ? '?' . http_build_query($q) : '');
}
$total_bots = safeCount($pdo, 'SELECT COUNT(*) FROM bots');
$total_themes = count($all_themes);
$total_users = safeCount($pdo, 'SELECT COUNT(*) FROM users');
$total_commissions = safeCount($pdo, 'SELECT COUNT(*) FROM commissions');

$hero_image = 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&w=900&q=80';
$hero_image_file = __DIR__ . '/uploads/home_hero.jpg';
$hero_upload_error = '';
$hero_upload_success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_hero_image'])) {
    if (!isAdmin()) {
        die('Access denied');
    }

    if (!isset($_FILES['hero_image']) || $_FILES['hero_image']['error'] === UPLOAD_ERR_NO_FILE) {
        $hero_upload_error = 'Please choose an image file.';
    } elseif ($_FILES['hero_image']['error'] !== UPLOAD_ERR_OK) {
        $hero_upload_error = 'Upload failed. Please try again.';
    } else {
        $maxSize = 10 * 1024 * 1024;
        if ((int)$_FILES['hero_image']['size'] > $maxSize) {
            $hero_upload_error = 'Image must be 10MB or smaller.';
        } else {
            $ext = strtolower(pathinfo($_FILES['hero_image']['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
            $imgInfo = @getimagesize($_FILES['hero_image']['tmp_name']);
            if (!in_array($ext, $allowed, true) || $imgInfo === false || !in_array($imgInfo[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_GIF, IMAGETYPE_WEBP], true)) {
                $hero_upload_error = 'Only real JPG, PNG, WEBP, or GIF images are allowed.';
            } else {
                $targetDir = __DIR__ . '/uploads/';
                if (!is_dir($targetDir)) {
                    mkdir($targetDir, 0755, true);
                }
                $newName = 'home_hero.jpg';
                $dest = $targetDir . $newName;
                if (move_uploaded_file($_FILES['hero_image']['tmp_name'], $dest)) {
                    $hero_image = '/anyn/uploads/' . $newName . '?v=' . time();
                    $hero_upload_success = 'Hero image updated successfully.';
                } else {
                    $hero_upload_error = 'Could not save uploaded image.';
                }
            }
        }
    }
}

if (file_exists($hero_image_file)) {
    $hero_image = '/anyn/uploads/home_hero.jpg?v=' . filemtime($hero_image_file);
}
?>

<style>
    .home-hero {
        position: relative;
        overflow: hidden;
        border-radius: 30px;
        padding: 34px;
        background:
            radial-gradient(circle at top right, rgba(255, 127, 158, 0.22), transparent 28%),
            radial-gradient(circle at bottom left, rgba(168, 85, 247, 0.14), transparent 32%),
            linear-gradient(135deg, rgba(255, 183, 197, 0.26), rgba(255, 255, 255, 0.92));
        border: 1px solid var(--border);
        box-shadow: var(--shadow-lg);
        margin-bottom: 24px;
    }

    .home-hero::before {
        content: '';
        position: absolute;
        inset: auto -120px -120px auto;
        width: 320px;
        height: 320px;
        background: radial-gradient(circle, rgba(255, 127, 158, 0.16), transparent 70%);
        pointer-events: none;
    }

    .home-hero-grid {
        position: relative;
        z-index: 1;
        display: grid;
        grid-template-columns: 1.2fr 0.8fr;
        gap: 22px;
        align-items: center;
    }

    .hero-kicker {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 8px 12px;
        border-radius: 999px;
        background: var(--surface);
        border: 1px solid var(--border);
        color: var(--pink-dark);
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: .45px;
        margin-bottom: 16px;
    }

    .hero-title {
        font-family: 'Playfair Display', serif;
        font-size: clamp(34px, 4.6vw, 58px);
        line-height: 1.02;
        letter-spacing: -1px;
        color: var(--text);
        margin-bottom: 14px;
        max-width: 760px;
    }

    .hero-desc {
        color: var(--text-2);
        font-size: 16px;
        line-height: 1.8;
        max-width: 720px;
    }

    .hero-actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
        margin-top: 24px;
    }

    .hero-actions .hero-btn { min-height: 46px; }

    .hero-btn {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        padding: 12px 18px;
        border-radius: 14px;
        font-size: 14px;
        font-weight: 800;
        text-decoration: none;
        transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
    }

    .hero-btn.primary {
        background: linear-gradient(135deg, var(--pink), var(--pink-dark));
        color: #fff;
        box-shadow: 0 12px 24px rgba(255, 127, 158, .28);
    }

    .hero-btn.secondary {
        background: var(--surface);
        color: var(--text-2);
        border: 1px solid var(--border);
    }

    .hero-btn:hover {
        transform: translateY(-2px);
    }

    .hero-panel {
        background: rgba(255,255,255,.7);
        border: 1px solid var(--border);
        border-radius: 24px;
        padding: 18px;
        box-shadow: var(--shadow-md);
        backdrop-filter: blur(12px);
    }

    .hero-panel-top {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 10px;
        margin-bottom: 14px;
    }

    .hero-panel-badge {
        padding: 7px 12px;
        border-radius: 999px;
        background: var(--pink-soft);
        color: var(--pink-dark);
        font-size: 12px;
        font-weight: 800;
    }

    .hero-panel-image {
        width: 100%;
        aspect-ratio: 1 / 1;
        object-fit: cover;
        border-radius: 18px;
        border: 1px solid var(--border);
        box-shadow: var(--shadow-sm);
    }

    .hero-mini-grid {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 10px;
        margin-top: 12px;
    }

    .mini-stat {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 14px;
    }

    .mini-stat .value {
        display: block;
        font-size: 22px;
        font-weight: 900;
        color: var(--text);
        line-height: 1;
    }

    .mini-stat .label {
        display: block;
        margin-top: 7px;
        color: var(--text-3);
        font-size: 12px;
        font-weight: 700;
    }

    .home-stats {
        display: grid;
        grid-template-columns: repeat(4, minmax(0, 1fr));
        gap: 14px;
        margin-bottom: 28px;
    }

    .stat-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 22px;
        padding: 18px;
        box-shadow: var(--shadow-sm);
        transition: transform .2s ease, box-shadow .2s ease;
    }

    .stat-card:hover {
        transform: translateY(-3px);
        box-shadow: var(--shadow-md);
    }

    .stat-card .stat-label {
        color: var(--text-2);
        font-size: 12px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: .4px;
    }

    .stat-card .stat-value {
        margin-top: 10px;
        font-size: 28px;
        line-height: 1;
        font-weight: 900;
        color: var(--text);
    }

    .stat-card .stat-sub {
        margin-top: 7px;
        color: var(--text-3);
        font-size: 12px;
    }

    .home-section-head {
        display: flex;
        align-items: end;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
        margin: 10px 0 16px;
    }

    .home-section-head p {
        color: var(--text-3);
        font-size: 14px;
    }

    .filters-row {
        display: flex;
        gap: 8px;
        flex-wrap: wrap;
        margin-bottom: 32px;
        align-items: center;
    }

    .bots-grid {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
        gap: 22px;
    }

    .bot-card { min-width: 0; }

    .empty-state {
        grid-column: 1/-1;
        text-align: center;
        padding: 80px 20px;
        color: var(--text-3);
    }

    .filters-row { overflow-x: auto; padding-bottom: 4px; -webkit-overflow-scrolling: touch; }

    .empty-state i { font-size: 48px; margin-bottom: 16px; display: block; }
    .empty-state p { font-size: 16px; }

    .card-img-wrap {
        position: relative;
        overflow: hidden;
    }

    .card-img-wrap img {
        transition: transform .4s ease;
    }

    .bot-card:hover .card-img-wrap img {
        transform: scale(1.04);
    }

    .card-tags {
        display: flex;
        flex-wrap: wrap;
        gap: 4px;
        justify-content: center;
        margin-bottom: 10px;
    }

    .card-meta {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 6px;
        font-size: 13px;
        font-weight: 700;
        color: #f4a22d;
    }

    .promo-strip {
        margin: 24px 0 28px;
        padding: 18px 20px;
        border-radius: 22px;
        background: linear-gradient(135deg, rgba(255,183,197,.25), rgba(255,255,255,.9));
        border: 1px solid var(--border);
        box-shadow: var(--shadow-sm);
        display: flex;
        justify-content: space-between;
        gap: 14px;
        align-items: center;
        flex-wrap: wrap;
    }

    .promo-strip strong {
        display: block;
        font-size: 15px;
        color: var(--text);
        margin-bottom: 4px;
    }

    .promo-strip span {
        color: var(--text-2);
        font-size: 13px;
    }

    .error-box,.success-box{padding:12px 14px;border-radius:12px;font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px}.error-box{background:#fef2f2;color:#dc2626;border:1px solid #fca5a5}.success-box{background:#f0fdf4;color:#16a34a;border:1px solid #86efac}

    .hero-upload-hint{font-size:12px;color:var(--text-3);line-height:1.6}

    @media (max-width: 920px) {
        .home-hero-grid,
        .home-stats {
            grid-template-columns: 1fr 1fr;
        }
    }

    @media (max-width: 640px) {
        .home-hero {
            padding: 18px 16px;
            border-radius: 18px;
        }

        .home-hero-grid,
        .home-stats,
        .hero-mini-grid {
            grid-template-columns: 1fr;
        }

        .hero-title { font-size: 30px; }
        .hero-desc   { font-size: 15px; }
        .hero-actions { flex-direction: column; }
        .hero-btn   { width: 100%; justify-content: center; }

        .bots-grid { grid-template-columns: repeat(2, 1fr); gap: 10px; }
        .bot-card  { border-radius: 14px; }
        .card-img-wrap { height: 150px; }
        .bot-card-body { padding: 10px 10px 12px; }
        .filter-pill { padding: 7px 14px; font-size: 12px; }
    }

    /* Single column on very small phones */
    @media (max-width: 400px) {
        .bots-grid { grid-template-columns: 1fr; }
        .hero-title { font-size: 26px; }
        .filters-row { gap: 6px; }
    }
</style>

<div class="home-hero animate-in">
    <div class="home-hero-grid">
        <div>
            <div class="hero-kicker"><i class="fa-solid fa-sparkles"></i> Explore the world of Anyn</div>
            <h1 class="hero-title">Discover characters, commissions, and community in one beautiful space.</h1>
            <p class="hero-desc">A more immersive landing-style homepage for browsing characters, filtering by themes, and jumping into the most exciting parts of the platform with just one click.</p>
            <div class="hero-actions">
                <a class="hero-btn primary" href="#characters"><i class="fa-solid fa-compass"></i> Explore characters</a>
                <?php if (!isset($_SESSION['user_id'])): ?>
                    <a class="hero-btn secondary" href="pages/login.php"><i class="fa-regular fa-user"></i> Sign in</a>
                <?php endif; ?>
            </div>
            <?php if (!empty($hero_upload_error)): ?>
                <div class="error-box" style="margin-top:18px;"><i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($hero_upload_error) ?></div>
            <?php endif; ?>
            <?php if (!empty($hero_upload_success)): ?>
                <div class="success-box" style="margin-top:18px;"><i class="fa-solid fa-circle-check"></i> <?= htmlspecialchars($hero_upload_success) ?></div>
            <?php endif; ?>
        </div>

        <div class="hero-panel">
            <div class="hero-panel-top">
                <div class="hero-panel-badge"><i class="fa-solid fa-crown"></i> Featured vibe</div>
                <div style="color:var(--text-3);font-size:12px;font-weight:700;">Live community</div>
            </div>
            <?php if (isAdmin()): ?>
            <form method="POST" enctype="multipart/form-data" style="display:grid;gap:12px;">
                <input type="hidden" name="update_hero_image" value="1">
                <?= csrf_field() ?>
                <img class="hero-panel-image" src="<?= htmlspecialchars($hero_image) ?>" alt="Anyn showcase" loading="lazy">
                <input type="file" name="hero_image" accept="image/jpeg,image/png,image/webp,image/gif" class="form-input">
                <button type="submit" class="hero-btn primary" style="border:none;cursor:pointer;justify-content:center;">Upload / Replace hero image</button>
                <div class="hero-upload-hint">Supports JPG, PNG, WEBP, GIF. Max 10MB.</div>
            </form>
            <?php else: ?>
                <img class="hero-panel-image" src="<?= htmlspecialchars($hero_image) ?>" alt="Anyn showcase" loading="lazy">
            <?php endif; ?>
            <div class="hero-mini-grid">
                <div class="mini-stat"><span class="value"><?= number_format($total_bots) ?></span><span class="label">Characters</span></div>
                <div class="mini-stat"><span class="value"><?= number_format($total_themes) ?></span><span class="label">Themes</span></div>
                <div class="mini-stat"><span class="value"><?= number_format($total_users) ?></span><span class="label">Members</span></div>
                <div class="mini-stat"><span class="value"><?= number_format($total_commissions) ?></span><span class="label">Commissions</span></div>
            </div>
        </div>
    </div>
</div>

<div class="home-stats">
    <div class="stat-card"><div class="stat-label">Characters</div><div class="stat-value"><?= number_format($total_bots) ?></div><div class="stat-sub">Ready to explore now</div></div>
    <div class="stat-card"><div class="stat-label">Themes</div><div class="stat-value"><?= number_format($total_themes) ?></div><div class="stat-sub">For easy discovery</div></div>
    <div class="stat-card"><div class="stat-label">Members</div><div class="stat-value"><?= number_format($total_users) ?></div><div class="stat-sub">Growing community</div></div>
    <div class="stat-card"><div class="stat-label">Commissions</div><div class="stat-value"><?= number_format($total_commissions) ?></div><div class="stat-sub">Custom requests received</div></div>
</div>

<div class="promo-strip">
    <div>
        <strong>New here? Start with the featured characters.</strong>
        <span>Use filters to quickly browse by mood, genre, or style.</span>
    </div>
    <a class="hero-btn primary" href="pages/register.php"><i class="fa-solid fa-arrow-right"></i> Create free account</a>
</div>

<div class="home-section-head">
    <div>
        <h2 class="section-title" id="characters">
            <?= $search !== '' ? 'Search: "'.htmlspecialchars($search).'"' : 'Recommended Characters' ?>
        </h2>
        <p>Curated picks and community favorites, presented in a smoother, more engaging layout.</p>
    </div>
</div>

<!-- Filter Pills -->
<div class="filters-row" id="themeFilters">
    <a href="index.php" data-filter-link class="filter-pill <?= $theme === '' && $search === '' ? 'active' : '' ?>">All</a>
    <?php foreach($all_themes as $th): ?>
        <a href="<?= htmlspecialchars(homeUrl(['theme' => $th, 'search' => '', 'page' => 1])) ?>" data-filter-link
           class="filter-pill <?= $theme === $th ? 'active' : '' ?>">
            <?= htmlspecialchars($th) ?>
        </a>
    <?php endforeach; ?>
</div>

<!-- Sort -->
<div class="filters-row" style="margin-top:-6px;">
    <span style="font-size:12px;font-weight:700;color:var(--text-3);align-self:center;">SORT</span>
    <?php foreach($sort_options as $key => $opt): ?>
        <a href="<?= htmlspecialchars(homeUrl(['sort' => $key, 'page' => 1])) ?>" data-filter-link
           class="filter-pill <?= $sort === $key ? 'active' : '' ?>"><?= $opt[0] ?></a>
    <?php endforeach; ?>
    <span style="font-size:12px;color:var(--text-3);align-self:center;margin-left:auto;"><?= number_format($filtered_total) ?> result<?= $filtered_total === 1 ? '' : 's' ?></span>
</div>

<!-- Bot Grid -->
<div class="bots-grid">
    <?php if(empty($bots)): ?>
        <div class="empty-state">
            <i class="fa-regular fa-face-sad-tear"></i>
            <p>No characters found. Try a different search.</p>
        </div>
    <?php endif; ?>

    <?php foreach ($bots as $bot): ?>
        <div class="bot-card animate-in" onclick="window.location.href='pages/bot_detail.php?id=<?= $bot['id'] ?>';">
            <div class="card-img-wrap">
                <img src="<?= htmlspecialchars($bot['image_url']) ?>" alt="<?= htmlspecialchars($bot['name']) ?>" loading="lazy">
                <?php if($bot['is_pinned']): ?>
                    <div class="badge-featured">FEATURED</div>
                <?php endif; ?>
            </div>
            <div class="bot-card-body">
                <div class="bot-title"><?= htmlspecialchars($bot['name']) ?></div>
                <?php if(visibleThemeNames($bot['theme_names'] ?? null)): ?>
                <div class="card-tags">
                    <?php foreach(visibleThemeNames($bot['theme_names']) as $t): ?>
                        <span class="tag-pill"><?= htmlspecialchars($t) ?></span>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
                <div class="card-meta">
                    <i class="fa-solid fa-star" style="font-size:12px;"></i>
                    <?= number_format($bot['total_rating'], 1) ?>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php if($total_pages > 1): ?>
<div class="filters-row" style="justify-content:center;margin-top:28px;">
    <?php if($page > 1): ?><a class="filter-pill" data-scroll-top href="<?= htmlspecialchars(homeUrl(['page' => $page - 1])) ?>">‹ Prev</a><?php endif; ?>
    <?php for($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
        <a class="filter-pill <?= $i === $page ? 'active' : '' ?>" data-scroll-top href="<?= htmlspecialchars(homeUrl(['page' => $i])) ?>"><?= $i ?></a>
    <?php endfor; ?>
    <?php if($page < $total_pages): ?><a class="filter-pill" data-scroll-top href="<?= htmlspecialchars(homeUrl(['page' => $page + 1])) ?>">Next ›</a><?php endif; ?>
</div>
<?php endif; ?>


<?php require_once 'includes/footer.php'; ?>