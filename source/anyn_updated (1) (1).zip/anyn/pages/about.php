<?php
$page_title = 'About Anyn';
$page_desc  = 'Learn about Anyn — a personal portfolio of roleplay characters, AI-generated art, and custom commissions.';
require_once '../config/database.php';
require_once '../includes/header.php';
?>

<style>
    .about-hero {
        background: linear-gradient(135deg, rgba(255,183,197,.22), rgba(255,255,255,.9));
        border: 1px solid var(--border);
        border-radius: 28px;
        padding: 52px 48px;
        margin-bottom: 28px;
        box-shadow: var(--shadow-md);
        position: relative;
        overflow: hidden;
    }
    .about-hero::before {
        content: '';
        position: absolute;
        inset: auto -80px -80px auto;
        width: 260px; height: 260px;
        background: radial-gradient(circle, rgba(255,127,158,.18), transparent 70%);
        pointer-events: none;
    }
    .about-hero-badge {
        display: inline-flex; align-items: center; gap: 8px;
        padding: 7px 14px; border-radius: 99px;
        background: var(--surface); border: 1px solid var(--border);
        color: var(--pink-dark); font-size: 12px; font-weight: 800;
        text-transform: uppercase; letter-spacing: .4px; margin-bottom: 18px;
    }
    .about-hero h1 {
        font-family: 'Playfair Display', serif;
        font-size: clamp(32px, 4vw, 52px);
        line-height: 1.08; letter-spacing: -.8px;
        color: var(--text); margin-bottom: 16px;
    }
    .about-hero p {
        color: var(--text-2); font-size: 17px; line-height: 1.8;
        max-width: 660px;
    }
    .about-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 18px;
        margin-bottom: 28px;
    }
    .about-card {
        background: var(--surface);
        border: 1.5px solid var(--border);
        border-radius: 22px;
        padding: 28px 24px;
        box-shadow: var(--shadow-sm);
        transition: transform .2s, box-shadow .2s;
    }
    .about-card:hover { transform: translateY(-4px); box-shadow: var(--shadow-md); }
    .about-card-icon {
        width: 48px; height: 48px;
        background: var(--pink-soft);
        border-radius: 14px;
        display: flex; align-items: center; justify-content: center;
        font-size: 22px;
        margin-bottom: 16px;
        color: var(--pink-dark);
    }
    .about-card h3 {
        font-size: 16px; font-weight: 800;
        color: var(--text); margin-bottom: 10px;
    }
    .about-card p { font-size: 14px; color: var(--text-2); line-height: 1.75; }
    .about-section {
        background: var(--surface);
        border: 1.5px solid var(--border);
        border-radius: 22px;
        padding: 36px;
        box-shadow: var(--shadow-sm);
        margin-bottom: 20px;
    }
    .about-section h2 {
        font-family: 'Playfair Display', serif;
        font-size: 22px; color: var(--text);
        margin-bottom: 16px;
        display: flex; align-items: center; gap: 10px;
    }
    .about-section h2::before {
        content: ''; width: 4px; height: 24px;
        background: var(--pink); border-radius: 2px; flex-shrink: 0;
    }
    .about-section p, .about-section li {
        font-size: 15px; color: var(--text-2); line-height: 1.8;
    }
    .about-section ul { padding-left: 20px; }
    .about-section li { margin-bottom: 8px; }
    .about-cta {
        background: linear-gradient(135deg, var(--pink), var(--pink-dark));
        border-radius: 22px;
        padding: 36px;
        text-align: center;
        color: white;
        box-shadow: 0 12px 32px rgba(255,127,158,.3);
    }
    .about-cta h2 {
        font-family: 'Playfair Display', serif;
        font-size: 26px; margin-bottom: 12px;
    }
    .about-cta p { opacity: .9; font-size: 15px; margin-bottom: 24px; }
    .about-cta-btns { display: flex; gap: 12px; justify-content: center; flex-wrap: wrap; }
    .cta-btn-white {
        background: white; color: var(--pink-dark);
        padding: 12px 24px; border-radius: 12px;
        font-weight: 800; font-size: 14px;
        text-decoration: none;
        transition: transform .2s, box-shadow .2s;
        display: inline-flex; align-items: center; gap: 8px;
    }
    .cta-btn-white:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(0,0,0,.12); }
    .cta-btn-outline {
        background: transparent; color: white;
        padding: 12px 24px; border-radius: 12px;
        font-weight: 800; font-size: 14px;
        text-decoration: none; border: 2px solid rgba(255,255,255,.6);
        transition: all .2s;
        display: inline-flex; align-items: center; gap: 8px;
    }
    .cta-btn-outline:hover { background: rgba(255,255,255,.15); border-color: white; }
    @media (max-width: 768px) {
        .about-grid    { grid-template-columns: 1fr; }
        .about-hero    { padding: 28px 20px; }
        .about-section { padding: 20px 16px; }
        .about-cta     { padding: 28px 20px; }
        .about-cta-btns { flex-direction: column; align-items: center; }
        .cta-btn-white, .cta-btn-outline { width: 100%; justify-content: center; }
    }

    @media (max-width: 400px) {
        .about-hero h1 { font-size: 26px; }
    }
</style>

<div class="about-hero animate-in">
    <div class="about-hero-badge"><i class="fa-solid fa-sparkles"></i> About Me</div>
    <h1>A personal space for digital characters and AI creativity.</h1>
    <p>Hi, I'm Anyn. What started as a fascination with storytelling has grown into my personal portfolio—a place where I bring imaginative roleplay bots and digital art to life.</p>
</div>

<div class="about-grid animate-in">
    <div class="about-card">
        <div class="about-card-icon"><i class="fa-solid fa-robot"></i></div>
        <h3>Unique Characters</h3>
        <p>Browse my collection of handcrafted roleplay characters. Each character is designed with detailed personality prompts, rich backstories, and carefully curated aesthetics.</p>
    </div>
    <div class="about-card">
        <div class="about-card-icon"><i class="fa-solid fa-palette"></i></div>
        <h3>Art Portfolio</h3>
        <p>A gallery showcasing my digital artwork. I experiment with various AI generation tools like PixAI, ChatGPT, and SeaArt to create unique character designs and visual narratives.</p>
    </div>
    <div class="about-card">
        <div class="about-card-icon"><i class="fa-solid fa-wand-magic-sparkles"></i></div>
        <h3>Custom Commissions</h3>
        <p>Have a specific character idea in mind? You can request a bespoke bot crafted to your exact specifications — from deep personality nuances to specific interactive scenarios.</p>
    </div>
</div>

<div class="about-section animate-in">
    <h2>Who is Anyn?</h2>
    <p>Anyn is my personal digital identity. Behind the screen, I am a creator who loves blending technical skills in web development and database management (like PHP and MySQL) with a deep passion for anime, gaming, and AI. I built this platform from scratch to showcase my digital character portfolio and share my creative experiments.</p>
    <p style="margin-top:12px;">Every feature here is a reflection of my journey as both a developer and a storyteller. I believe in giving my creations a beautiful, thoughtful space, ensuring every bot and piece of art has its own unique soul and depth.</p>
</div>

<div class="about-section animate-in">
    <h2>Guidelines & Terms</h2>
    <ul>
        <li><strong>Respect the characters</strong> — Please interact thoughtfully with the bots I've created.</li>
        <li><strong>Fictional content only</strong> — All my characters and artworks are purely fictional, inspired by various media and imaginative concepts.</li>
        <li><strong>Credit the creator</strong> — If you share my bots or artwork elsewhere, please link back to this site or my Anyn profile.</li>
        <li><strong>Constructive feedback</strong> — I am always looking to improve my prompts and scenarios, so feel free to share your experiences!</li>
    </ul>
</div>

<div class="about-section animate-in">
    <h2>Contact & Support</h2>
    <p>Want to request a commission, discuss an idea, or just say hi? The fastest way to reach me is through my <a href="<?= ANYN_DISCORD_URL ?>" target="_blank" rel="noopener noreferrer" style="color:var(--pink-dark);font-weight:700;">Discord server</a>. You can also email me directly at <a href="mailto:prismvow.art@gmail.com" style="color:var(--pink-dark);font-weight:700;">prismvow.art@gmail.com</a>.</p>
    <p style="margin-top:10px;">I usually aim to respond within 24–48 hours.</p>
</div>

<div class="about-cta animate-in">
    <h2>Ready to explore?</h2>
    <p>Browse my character portfolio, check out the gallery, or request your own custom bot.</p>
    <div class="about-cta-btns">
        <?php if (!isset($_SESSION['user_id'])): ?>
            <a href="register.php" class="cta-btn-white"><i class="fa-solid fa-user-plus"></i> Create free account</a>
        <?php endif; ?>
        <a href="../index.php" class="cta-btn-white"><i class="fa-solid fa-compass"></i> Explore my work</a>
        <a href="<?= ANYN_DISCORD_URL ?>" target="_blank" rel="noopener noreferrer" class="cta-btn-outline">
            <i class="fa-brands fa-discord"></i> Join my Discord
        </a>
    </div>
</div>

<?php require_once '../includes/footer.php'; ?>