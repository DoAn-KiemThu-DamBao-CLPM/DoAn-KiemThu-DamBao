<?php
require_once '../config/database.php';

// Chỉ cho Admin (ID=1) vào, không là user nó phá nát web
if (!isAdmin()) {
    header("Location: ../index.php");
    exit();
}

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    csrf_verify();
    $name = clean_text($_POST['name'] ?? '', 120);
    $desc = clean_text($_POST['description'] ?? '', 5000);
    $is_pinned = isset($_POST['is_pinned']) ? 1 : 0;

    $final_image_url = '';

    // XỬ LÝ UPLOAD ẢNH TRỰC TIẾP TỪ MÁY (kiểm tra MIME thật, tên file ngẫu nhiên)
    if ($name === '') {
        $message = "Name is required.";
    } elseif (isset($_FILES['bot_image']) && $_FILES['bot_image']['error'] == 0) {
        $valid_ext = validate_image_upload($_FILES['bot_image'], 5 * 1024 * 1024);
        if (!$valid_ext) {
            $message = "Invalid image (JPG/PNG/GIF/WEBP, max 5MB).";
        } else {
            $target_dir = "../uploads/";
            $file_name = time() . "_" . bin2hex(random_bytes(6)) . "." . $valid_ext;
            if (move_uploaded_file($_FILES["bot_image"]["tmp_name"], $target_dir . $file_name)) {
                $final_image_url = "/anyn/uploads/" . $file_name;
            } else {
                $message = "Upload failed.";
            }
        }
    }

    if ($final_image_url) {
        try {
            // juicy_url / crushon_url are legacy columns: kept blank so older schemas still accept the insert.
            $sql = "INSERT INTO bots (name, description, image_url, juicy_url, crushon_url, is_pinned) 
                    VALUES (?, ?, ?, '', '', ?)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([$name, $desc, $final_image_url, $is_pinned]);
            $message = "Thêm Bot thành công! Quá nhanh quá nguy hiểm.";
        } catch (PDOException $e) {
            error_log($e->getMessage());
            $message = "Database error. Please try again.";
        }
    }
}

require_once '../includes/header.php';
?>

<div style="max-width: 800px; margin: 0 auto; background: var(--surface); padding: 40px; border-radius: 20px; box-shadow: var(--shadow-md);">
    <h2 style="color: var(--pink-dark); margin-top: 0;"><i class="fa-solid fa-plus"></i> Thêm Bot Mới</h2>
    
    <?php if($message): ?>
        <div style="padding: 15px; background: #f0fdf4; color: #16a34a; border-radius: 10px; margin-bottom: 20px; border: 1px solid #bbf7d0;">
            <?= htmlspecialchars($message) ?>
        </div>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <div style="margin-bottom: 20px;">
            <label style="display:block; font-weight:bold; margin-bottom:8px;">Tên Bot:</label>
            <input type="text" name="name" required style="width:100%; padding:12px; border:1px solid #ddd; border-radius:10px;">
        </div>

        <div style="margin-bottom: 20px;">
            <label style="display:block; font-weight:bold; margin-bottom:8px;">Mô tả:</label>
            <textarea name="description" required style="width:100%; height:100px; padding:12px; border:1px solid #ddd; border-radius:10px;"></textarea>
        </div>

        <!-- KHÚC NÀY LÀ ĐỂ ÚP ẢNH TỪ MÁY NÈ -->
        <div style="margin-bottom: 20px;">
            <label style="display:block; font-weight:bold; margin-bottom:8px;">Ảnh đại diện (Chọn từ máy m):</label>
            <input type="file" name="bot_image" accept="image/*" required>
        </div>

        <div style="margin-bottom: 30px;">
            <label><input type="checkbox" name="is_pinned"> Ghim lên đầu trang chủ</label>
        </div>

        <button <?= csrf_field() ?>
                    <button type="submit" class="btn-pink" style="width: 100%; padding: 15px; font-size: 16px;">XÁC NHẬN THÊM BOT</button>
    </form>
</div>

<?php require_once '../includes/footer.php'; ?>