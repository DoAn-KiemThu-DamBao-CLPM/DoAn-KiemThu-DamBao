<?php
$page_title = 'Admin — Stats';
require_once '../config/database.php';

if (!isAdmin()) {
    die("<div style='color:#ef4444;text-align:center;padding:60px;font-family:sans-serif;'><h3>Access Denied</h3></div>");
}

require_once '../includes/gems_lib.php';
ensureGemsSchema($pdo);

// ── Collect stats ──────────────────────────────────────────────
function safeQ(PDO $pdo, string $sql): int {
    try { return (int)$pdo->query($sql)->fetchColumn(); } catch(Throwable $e) { return 0; }
}

$total_users       = safeQ($pdo, 'SELECT COUNT(*) FROM users');
$total_bots        = safeQ($pdo, 'SELECT COUNT(*) FROM bots');
$total_themes      = safeQ($pdo, 'SELECT COUNT(*) FROM themes');
$total_comments    = safeQ($pdo, 'SELECT COUNT(*) FROM comments');
$total_ratings     = safeQ($pdo, 'SELECT COUNT(*) FROM ratings');
$total_commissions = safeQ($pdo, 'SELECT COUNT(*) FROM commissions');
$pending_commissions = safeQ($pdo, "SELECT COUNT(*) FROM commissions WHERE status='pending'");
$total_ideas       = safeQ($pdo, 'SELECT COUNT(*) FROM ideas');
$open_ideas        = safeQ($pdo, "SELECT COUNT(*) FROM ideas WHERE work_status='open'");
$comm_posts        = safeQ($pdo, 'SELECT COUNT(*) FROM community_posts');
$pending_posts     = safeQ($pdo, "SELECT COUNT(*) FROM community_posts WHERE status='pending'");
$gem_txns          = safeQ($pdo, 'SELECT COUNT(*) FROM gem_transactions');

// Top rated bots
$top_bots = $pdo->query("SELECT name, total_rating, image_url FROM bots ORDER BY total_rating DESC LIMIT 5")->fetchAll();

// Recent registrations
$recent_users = $pdo->query("SELECT username, created_at FROM users ORDER BY created_at DESC LIMIT 8")->fetchAll();

// Commission status breakdown
$com_statuses = $pdo->query("SELECT status, COUNT(*) as cnt FROM commissions GROUP BY status")->fetchAll();

require_once '../includes/header.php';
?>

<style>
    .stats-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
    .stat-tile {
        background: var(--surface); border: 1.5px solid var(--border);
        border-radius: 20px; padding: 20px; box-shadow: var(--shadow-sm);
        transition: transform .2s;
    }
    .stat-tile:hover { transform: translateY(-3px); box-shadow: var(--shadow-md); }
    .stat-tile .icon {
        width: 44px; height: 44px; border-radius: 12px;
        display: flex; align-items: center; justify-content: center;
        font-size: 20px; margin-bottom: 14px;
    }
    .stat-tile .val { font-size: 30px; font-weight: 900; color: var(--text); line-height: 1; }
    .stat-tile .lbl { margin-top: 6px; font-size: 12px; font-weight: 700; color: var(--text-3); text-transform: uppercase; letter-spacing: .4px; }
    .stat-tile .sub { margin-top: 4px; font-size: 12px; color: var(--text-3); }
    .pink-icon  { background: var(--pink-soft); color: var(--pink-dark); }
    .blue-icon  { background: #eff6ff; color: #3b82f6; }
    .green-icon { background: #f0fdf4; color: #16a34a; }
    .amber-icon { background: #fffbeb; color: #d97706; }
    .alert-badge { display:inline-block; background:#fef2f2; color:#dc2626; border:1px solid #fca5a5; border-radius:99px; font-size:11px; font-weight:700; padding:2px 8px; margin-left:6px; }
    .stats-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px; }
    .stats-panel {
        background: var(--surface); border: 1.5px solid var(--border);
        border-radius: 20px; padding: 24px; box-shadow: var(--shadow-sm);
    }
    .stats-panel h3 {
        font-family: 'Playfair Display', serif; font-size: 17px;
        color: var(--text); margin-bottom: 18px;
        display: flex; align-items: center; gap: 8px;
    }
    .stats-panel h3::before { content:''; width:3px; height:20px; background:var(--pink); border-radius:2px; flex-shrink:0; }
    .mini-bot { display: flex; align-items: center; gap: 12px; padding: 10px 0; border-bottom: 1px solid var(--border); }
    .mini-bot:last-child { border-bottom: none; }
    .mini-bot img { width: 42px; height: 42px; border-radius: 10px; object-fit:cover; border:1px solid var(--border); flex-shrink:0; }
    .mini-bot .bname { font-weight: 700; font-size: 14px; color: var(--text); }
    .mini-bot .brating { font-size: 12px; color: #f4a22d; font-weight: 700; margin-top:2px; }
    .user-row { display:flex; justify-content:space-between; padding:9px 0; border-bottom:1px solid var(--border); font-size:13px; }
    .user-row:last-child { border-bottom: none; }
    .user-row .uname { font-weight:700; color:var(--text); }
    .user-row .udate { color:var(--text-3); }
    .com-bar { display:flex; align-items:center; gap:10px; margin-bottom:12px; }
    .com-bar .clabel { min-width: 80px; font-size: 13px; font-weight:700; color:var(--text-2); text-transform:capitalize; }
    .com-bar .cbar { flex:1; background:var(--surface-2); border-radius:99px; height:10px; }
    .com-bar .cfill { height:10px; border-radius:99px; transition: width .4s; }
    .com-bar .ccount { min-width: 30px; text-align:right; font-size:12px; font-weight:700; color:var(--text-3); }
    @media(max-width:900px) {
        .stats-grid { grid-template-columns: repeat(2,1fr); }
        .stats-row  { grid-template-columns: 1fr; }
    }
    @media(max-width:500px) {
        .stats-grid { grid-template-columns: 1fr 1fr; }
    }
</style>

<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px;flex-wrap:wrap;gap:12px;">
    <h1 class="section-title" style="margin-bottom:0;">Admin Dashboard</h1>
    <span style="color:var(--text-3);font-size:13px;">Last updated: <?= date('d M Y, H:i') ?></span>
</div>

<!-- KPI Grid -->
<div class="stats-grid animate-in">
    <div class="stat-tile">
        <div class="icon pink-icon"><i class="fa-solid fa-users"></i></div>
        <div class="val"><?= number_format($total_users) ?></div>
        <div class="lbl">Members</div>
    </div>
    <div class="stat-tile">
        <div class="icon blue-icon"><i class="fa-solid fa-robot"></i></div>
        <div class="val"><?= number_format($total_bots) ?></div>
        <div class="lbl">Characters</div>
        <div class="sub"><?= $total_themes ?> themes</div>
    </div>
    <div class="stat-tile">
        <div class="icon green-icon"><i class="fa-solid fa-cart-shopping"></i></div>
        <div class="val"><?= number_format($total_commissions) ?></div>
        <div class="lbl">Commissions
            <?php if ($pending_commissions > 0): ?>
                <span class="alert-badge"><?= $pending_commissions ?> pending</span>
            <?php endif; ?>
        </div>
    </div>
    <div class="stat-tile">
        <div class="icon amber-icon"><i class="fa-regular fa-lightbulb"></i></div>
        <div class="val"><?= number_format($total_ideas) ?></div>
        <div class="lbl">Ideas
            <?php if ($open_ideas > 0): ?>
                <span class="alert-badge" style="background:#fff7ed;color:#c2410c;border-color:#fdba74;"><?= $open_ideas ?> open</span>
            <?php endif; ?>
        </div>
    </div>
    <div class="stat-tile">
        <div class="icon blue-icon"><i class="fa-regular fa-image"></i></div>
        <div class="val"><?= number_format($comm_posts) ?></div>
        <div class="lbl">Community Posts
            <?php if ($pending_posts > 0): ?>
                <span class="alert-badge"><?= $pending_posts ?> pending</span>
            <?php endif; ?>
        </div>
    </div>
    <div class="stat-tile">
        <div class="icon green-icon"><i class="fa-solid fa-star"></i></div>
        <div class="val"><?= number_format($total_ratings) ?></div>
        <div class="lbl">Ratings</div>
        <div class="sub"><?= number_format($total_comments) ?> comments</div>
    </div>
    <div class="stat-tile">
        <div class="icon amber-icon"><i class="fa-solid fa-gem"></i></div>
        <div class="val"><?= number_format($gem_txns) ?></div>
        <div class="lbl">Gem Transactions</div>
    </div>
</div>

<!-- Quick actions -->
<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:28px;" class="animate-in">
    <a href="admin_bots.php"       class="hero-btn primary"   style="text-decoration:none;"><i class="fa-solid fa-robot"></i> Manage Bots</a>
    <a href="admin_community.php"  class="hero-btn secondary" style="text-decoration:none;"><i class="fa-solid fa-gavel"></i> Moderate Community
        <?php if ($pending_posts > 0): ?><span style="background:#dc2626;color:#fff;border-radius:99px;font-size:10px;padding:2px 7px;margin-left:4px;"><?= $pending_posts ?></span><?php endif; ?>
    </a>
    <a href="admin_bots.php?action=commissions" class="hero-btn secondary" style="text-decoration:none;"><i class="fa-solid fa-cart-shopping"></i> Commissions
        <?php if ($pending_commissions > 0): ?><span style="background:#dc2626;color:#fff;border-radius:99px;font-size:10px;padding:2px 7px;margin-left:4px;"><?= $pending_commissions ?></span><?php endif; ?>
    </a>
    <a href="admin_add_bot.php"    class="hero-btn secondary" style="text-decoration:none;"><i class="fa-solid fa-plus"></i> Add Character</a>
</div>

<!-- Detail panels -->
<div class="stats-row animate-in">
    <div class="stats-panel">
        <h3>Top Rated Characters</h3>
        <?php foreach ($top_bots as $b): ?>
        <div class="mini-bot">
            <img src="<?= htmlspecialchars($b['image_url']) ?>" alt="">
            <div>
                <div class="bname"><?= htmlspecialchars($b['name']) ?></div>
                <div class="brating"><i class="fa-solid fa-star" style="font-size:11px;"></i> <?= number_format($b['total_rating'], 2) ?></div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php if (empty($top_bots)): ?>
            <p style="color:var(--text-3);font-size:13px;">No bots yet.</p>
        <?php endif; ?>
    </div>

    <div class="stats-panel">
        <h3>Recent Registrations</h3>
        <?php foreach ($recent_users as $u): ?>
        <div class="user-row">
            <span class="uname"><i class="fa-regular fa-circle-user" style="color:var(--pink-dark);margin-right:6px;"></i><?= htmlspecialchars($u['username']) ?></span>
            <span class="udate"><?= date('d M Y', strtotime($u['created_at'])) ?></span>
        </div>
        <?php endforeach; ?>
        <?php if (empty($recent_users)): ?>
            <p style="color:var(--text-3);font-size:13px;">No users yet.</p>
        <?php endif; ?>
    </div>
</div>

<div class="stats-panel animate-in" style="margin-bottom:20px;">
    <h3>Commission Status Breakdown</h3>
    <?php
    $status_colors = ['pending'=>'#f59e0b','in_progress'=>'#3b82f6','completed'=>'#10b981','rejected'=>'#ef4444'];
    $max_com = max(1, array_sum(array_column($com_statuses,'cnt')));
    foreach ($com_statuses as $s): ?>
    <div class="com-bar">
        <div class="clabel"><?= htmlspecialchars($s['status']) ?></div>
        <div class="cbar">
            <div class="cfill" style="width:<?= round($s['cnt']/$max_com*100) ?>%;background:<?= $status_colors[$s['status']] ?? 'var(--pink)' ?>;"></div>
        </div>
        <div class="ccount"><?= $s['cnt'] ?></div>
    </div>
    <?php endforeach; ?>
    <?php if (empty($com_statuses)): ?>
        <p style="color:var(--text-3);font-size:13px;">No commissions yet.</p>
    <?php endif; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
