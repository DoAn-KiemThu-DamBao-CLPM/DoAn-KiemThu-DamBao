<?php
require_once '../config/database.php';

if (!isset($_GET['id'])) {
    header("Location: ../index.php"); 
    exit();
}

$bot_id = (int)$_GET['id'];

$stmt = $pdo->prepare("SELECT * FROM bots WHERE id = ?");
$stmt->execute([$bot_id]);
$bot = $stmt->fetch();

if (!$bot) {
    require_once '../includes/header.php';
    echo "<div style='text-align:center;padding:80px 20px;color:var(--text-3);'><i class='fa-regular fa-face-sad-tear' style='font-size:48px;display:block;margin-bottom:16px;'></i><p>Character not found.</p></div>";
    require_once '../includes/footer.php'; 
    exit();
}

// Handle rating POST
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_rating']) && isset($_SESSION['user_id'])) {
    csrf_verify();
    $score   = max(1, min(5, (int)$_POST['score']));
    $user_id = $_SESSION['user_id'];

    $check = $pdo->prepare("SELECT id FROM ratings WHERE user_id = ? AND bot_id = ?");
    $check->execute([$user_id, $bot_id]);
    
    if ($check->rowCount() > 0) {
        $pdo->prepare("UPDATE ratings SET score = ? WHERE user_id = ? AND bot_id = ?")->execute([$score, $user_id, $bot_id]);
    } else {
        $pdo->prepare("INSERT INTO ratings (user_id, bot_id, score) VALUES (?, ?, ?)")->execute([$user_id, $bot_id, $score]);
    }
    
    $avg = $pdo->prepare("SELECT AVG(score) as avg_s FROM ratings WHERE bot_id = ?");
    $avg->execute([$bot_id]);
    $new_avg = round($avg->fetch()['avg_s'], 2);
    $pdo->prepare("UPDATE bots SET total_rating = ? WHERE id = ?")->execute([$new_avg, $bot_id]);
    header("Location: bot_detail.php?id=$bot_id"); 
    exit();
}

// Handle comment POST (create)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_comment']) && isLoggedIn()) {
    $content = clean_text($_POST['content'] ?? '', 1000);
    if ($content !== '') {
        $pdo->prepare("INSERT INTO comments (user_id, bot_id, content) VALUES (?, ?, ?)")->execute([currentUserId(), $bot_id, $content]);
        header("Location: bot_detail.php?id=$bot_id#comments");
        exit();
    }
}

// Handle comment edit / delete (owner, or admin for delete)
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isLoggedIn() && (isset($_POST['edit_comment']) || isset($_POST['delete_comment']))) {
    $cid = (int)($_POST['comment_id'] ?? 0);
    $own = $pdo->prepare("SELECT id, user_id FROM comments WHERE id = ? AND bot_id = ?");
    $own->execute([$cid, $bot_id]);
    $row = $own->fetch();
    if ($row) {
        $is_owner = ((int)$row['user_id'] === currentUserId());
        if (isset($_POST['delete_comment']) && ($is_owner || isAdmin())) {
            $pdo->prepare("DELETE FROM comments WHERE id = ?")->execute([$cid]);
        } elseif (isset($_POST['edit_comment']) && $is_owner) {
            $new = clean_text($_POST['content'] ?? '', 1000);
            if ($new !== '') {
                $pdo->prepare("UPDATE comments SET content = ?, edited_at = NOW() WHERE id = ?")->execute([$new, $cid]);
            }
        }
    }
    header("Location: bot_detail.php?id=$bot_id#comments");
    exit();
}

// Fetch extra data
$stmt_tags = $pdo->prepare("SELECT t.name FROM themes t JOIN bot_themes bt ON t.id = bt.theme_id WHERE bt.bot_id = ?");
$stmt_tags->execute([$bot_id]);
$bot_tags = filterThemeNames($stmt_tags->fetchAll(PDO::FETCH_COLUMN));

$count_stmt = $pdo->prepare("SELECT COUNT(id) FROM ratings WHERE bot_id = ?");
$count_stmt->execute([$bot_id]);
$rating_count = $count_stmt->fetchColumn();

// Get user's existing rating
$user_rating_val = null;
if(isset($_SESSION['user_id'])) {
    $ur = $pdo->prepare("SELECT score FROM ratings WHERE user_id = ? AND bot_id = ?");
    $ur->execute([$_SESSION['user_id'], $bot_id]);
    $user_rating_val = $ur->fetchColumn();
}

$stmt_comments = $pdo->prepare("
    SELECT c.*, u.username, u.total_spent, u.avatar_url, r.score as user_rating 
    FROM comments c 
    JOIN users u ON c.user_id = u.id 
    LEFT JOIN ratings r ON c.user_id = r.user_id AND r.bot_id = c.bot_id 
    WHERE c.bot_id = ? 
    ORDER BY c.created_at DESC
");
$stmt_comments->execute([$bot_id]);
$comments = $stmt_comments->fetchAll();

$stmt_col = $pdo->prepare("SELECT g.name, g.id FROM bot_groups g JOIN bot_group_members bgm ON g.id = bgm.group_id WHERE bgm.bot_id = ?");
$stmt_col->execute([$bot_id]);
$collections = $stmt_col->fetchAll();

require_once '../includes/header.php';
?>

<style>
    /* Detail layout */
    .detail-grid {
        display: grid;
        grid-template-columns: 340px 1fr;
        gap: 36px;
        margin-bottom: 40px;
    }

    @media (max-width: 860px) {
        .detail-grid { grid-template-columns: 1fr; }
        .detail-grid.card { padding: 20px !important; }
    }

    .detail-img {
        width: 100%;
        border-radius: var(--radius);
        box-shadow: var(--shadow-md);
        aspect-ratio: 3/4;
        object-fit: cover;
    }

    .detail-info { min-width: 0; }

    .detail-name {
        font-family: 'Playfair Display', serif;
        font-size: 34px;
        font-weight: 700;
        color: var(--text);
        margin-bottom: 16px;
        line-height: 1.2;
    }

    .detail-tags { display: flex; flex-wrap: wrap; gap: 7px; margin-bottom: 18px; }

    .collection-link {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #e3f2fd;
        color: #1565c0;
        padding: 5px 14px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 700;
        margin-bottom: 18px;
        transition: background var(--transition);
    }

    [data-theme="dark"] .collection-link {
        background: #1a2a3a;
        color: #64b5f6;
    }

    .detail-access {
        font-size: 22px;
        font-weight: 800;
        color: var(--pink-dark);
        margin-bottom: 12px;
        letter-spacing: -.5px;
    }

    .detail-rating {
        display: flex;
        align-items: center;
        gap: 8px;
        margin-bottom: 20px;
        font-size: 17px;
        font-weight: 700;
        color: #f4a22d;
    }

    .detail-rating .count { color: var(--text-3); font-size: 13px; font-weight: 500; }

    .desc-box {
        background: var(--surface-2);
        padding: 20px;
        border-radius: var(--radius-sm);
        border-left: 3px solid var(--pink);
        margin-bottom: 24px;
        line-height: 1.75;
        font-size: 14px;
        color: var(--text-2);
        word-break: break-word;
    }

    .btn-start {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        background: linear-gradient(135deg, var(--pink) 0%, var(--pink-dark) 100%);
        color: #fff;
        padding: 15px 36px;
        border-radius: 99px;
        font-size: 16px;
        font-weight: 800;
        border: none;
        cursor: pointer;
        font-family: inherit;
        box-shadow: 0 8px 24px rgba(255,127,158,.35);
        transition: all var(--transition);
        letter-spacing: .3px;
        width: 100%;
        justify-content: center;
    }

    .btn-start:hover {
        transform: translateY(-3px);
        box-shadow: 0 14px 32px rgba(255,127,158,.45);
    }

    /* Bottom grid */
    .bottom-grid {
        display: grid;
        grid-template-columns: 280px 1fr;
        gap: 28px;
        margin-bottom: 60px;
    }

    .detail-grid.card,
    .bottom-grid .card { min-width: 0; }

    @media (max-width: 768px) {
        .bottom-grid { grid-template-columns: 1fr; }
    }

    /* Star Rating */
    .star-picker { display: flex; flex-direction: row-reverse; justify-content: flex-end; gap: 6px; margin-bottom: 18px; }

    .star-picker input { display: none; }

    .star-picker label {
        font-size: 28px;
        color: var(--border);
        cursor: pointer;
        transition: color var(--transition), transform var(--transition);
    }

    .star-picker label:hover,
    .star-picker label:hover ~ label,
    .star-picker input:checked ~ label {
        color: #f4a22d;
    }

    .star-picker label:hover { transform: scale(1.15); }

    /* Comments section */
    .comments-list { display: flex; flex-direction: column; gap: 18px; }

    .login-prompt {
        text-align: center;
        padding: 20px;
        background: var(--surface-2);
        border-radius: var(--radius-sm);
        border: 1.5px dashed var(--border);
        font-size: 14px;
        color: var(--text-2);
    }

    .login-prompt a { color: var(--pink-dark); font-weight: 700; }

    /* Prevent iOS Safari auto-zoom on input focus */
    @media (max-width: 768px) {
        .detail-grid { grid-template-columns: 1fr; gap: 18px; }
        .bottom-grid { grid-template-columns: 1fr; gap: 16px; }
        .detail-name { font-size: 28px; }
        .detail-access { font-size: 18px; }
        .detail-rating { font-size: 15px; flex-wrap: wrap; }
        .desc-box { padding: 16px; }
        .btn-start { padding: 14px 20px; }
        .star-picker label { font-size: 24px; }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="number"],
        input[type="search"],
        textarea, select {
            font-size: 16px !important;
        }
    }
</style>

<!-- Detail Section -->
<a href="../index.php" style="display:inline-flex;align-items:center;gap:8px;color:var(--text-3);font-size:13px;font-weight:600;margin-bottom:24px;transition:color var(--transition);" onmouseover="this.style.color='var(--pink-dark)'" onmouseout="this.style.color='var(--text-3)'">
    <i class="fa-solid fa-arrow-left"></i> Back to Characters
</a>

<div class="detail-grid card" style="padding:32px;">
    <div>
        <img src="<?= htmlspecialchars($bot['image_url']) ?>" class="detail-img" alt="<?= htmlspecialchars($bot['name']) ?>">
    </div>

    <div class="detail-info">
        <h1 class="detail-name"><?= htmlspecialchars($bot['name']) ?></h1>

        <?php if(!empty($bot_tags)): ?>
        <div class="detail-tags">
            <?php foreach($bot_tags as $tag_name): ?>
                <span class="tag-pill">🏷️ <?= htmlspecialchars($tag_name) ?></span>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <?php if($collections): ?>
        <div style="display:flex;flex-wrap:wrap;gap:8px;margin-bottom:18px;">
            <?php foreach($collections as $col): ?>
                <a href="group_detail.php?id=<?= $col['id'] ?>" class="collection-link">
                    <i class="fa-solid fa-folder-open"></i> <?= htmlspecialchars($col['name']) ?>
                </a>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="detail-access">✨ FREE ACCESS</div>

        <div class="detail-rating">
            <i class="fa-solid fa-star"></i>
            <?= number_format($bot['total_rating'], 1) ?>
            <span class="count">(<?= $rating_count ?> ratings)</span>
        </div>

        <div class="desc-box">
            <?php
            $full_desc = $bot['description'];
            $max_length = 450;
            $is_long = mb_strlen($full_desc, 'UTF-8') > $max_length;
            if ($is_long):
                $short_desc = mb_substr($full_desc, 0, $max_length, 'UTF-8') . '...';
            ?>
                <div id="desc-short"><?= nl2br(htmlspecialchars($short_desc)) ?></div>
                <div id="desc-full" style="display:none;"><?= nl2br(htmlspecialchars($full_desc)) ?></div>
                <button id="desc-toggle" onclick="toggleDesc()" style="background:none;border:none;color:var(--pink-dark);font-weight:700;padding:8px 0 0;cursor:pointer;font-size:13px;font-family:inherit;">
                    Show more ▼
                </button>
            <?php else: ?>
                <?= nl2br(htmlspecialchars($full_desc)) ?>
            <?php endif; ?>
        </div>

        <button type="button" onclick="showToast('Tính năng đang được phát triển')" class="btn-start">
            <i class="fa-solid fa-hand-pointer"></i> Tương tác
        </button>
    </div>
</div>

<!-- Bottom: Rating + Comments -->
<div class="bottom-grid">

    <!-- Rating Column -->
    <div class="card" style="padding:26px; height:fit-content;">
        <h3 style="margin:0 0 18px; font-size:17px; padding-bottom:14px; border-bottom:1.5px solid var(--border);">
            Rate this Character
        </h3>

        <?php if(isset($_SESSION['user_id'])): ?>
            <form method="POST">
                <div class="star-picker">
                    <?php for($s = 5; $s >= 1; $s--): ?>
                        <input type="radio" name="score" id="star<?= $s ?>" value="<?= $s ?>"
                               <?= ($user_rating_val == $s) ? 'checked' : '' ?>>
                        <label for="star<?= $s ?>" title="<?= $s ?> star<?= $s>1?'s':'' ?>">★</label>
                    <?php endfor; ?>
                </div>
                <?php if($user_rating_val): ?>
                    <p style="font-size:12px;color:var(--text-3);margin-bottom:14px;">Your rating: <?= $user_rating_val ?> ★ — click to update</p>
                <?php endif; ?>
                <?= csrf_field() ?>
                        <button type="submit" name="submit_rating" class="btn-pink" style="width:100%;justify-content:center;padding:11px;">
                    <i class="fa-solid fa-check"></i> Submit Rating
                </button>
            </form>
        <?php else: ?>
            <div class="login-prompt">
                Please <a href="login.php">log in</a> to rate this character.
            </div>
        <?php endif; ?>
    </div>

    <!-- Comments Column -->
    <div class="card" id="comments" style="padding:26px;">
        <h3 style="margin:0 0 18px; font-size:17px; padding-bottom:14px; border-bottom:1.5px solid var(--border);">
            Community Discussions <span style="color:var(--text-3);font-size:14px;font-weight:500;">(<?= count($comments) ?>)</span>
        </h3>

        <?php if(isset($_SESSION['user_id'])): ?>
            <form method="POST" style="margin-bottom:28px;">
                <textarea name="content" required maxlength="1000" class="form-textarea"
                          placeholder="Share your experience with this character..."
                          style="margin-bottom:12px;"></textarea>
                <?= csrf_field() ?>
                    <button type="submit" name="submit_comment" class="btn-pink" style="padding:10px 24px;">
                    <i class="fa-regular fa-paper-plane"></i> Post Comment
                </button>
            </form>
        <?php else: ?>
            <div class="login-prompt" style="margin-bottom:28px;">
                Please <a href="login.php">log in</a> to join the discussion.
            </div>
        <?php endif; ?>

        <div class="comments-list">
            <?php if(empty($comments)): ?>
                <p style="text-align:center;color:var(--text-3);font-style:italic;padding:30px 0;">
                    No comments yet. Be the first! 🌸
                </p>
            <?php endif; ?>

            <?php foreach($comments as $c):
                $is_premium  = ($c['total_spent'] >= 10);
                $avatar_img  = !empty($c['avatar_url']) ? htmlspecialchars($c['avatar_url']) : 'https://i.postimg.cc/mZh4H8hC/default-avatar.png';
                $frame_class = $is_premium ? 'frame-bloom' : 'frame-normal';
                $avt_class   = $is_premium ? 'comment-avatar premium' : 'comment-avatar';
            ?>
                <div class="comment-wrapper">
                    <img src="<?= $avatar_img ?>" class="<?= $avt_class ?>" alt="">
                    <div class="<?= $frame_class ?>" style="flex-grow:1;">
                        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:6px;">
                            <span class="comment-author">
                                <a href="user.php?id=<?= (int)$c['user_id'] ?>" style="color:inherit;text-decoration:none;"><?= htmlspecialchars($c['username']) ?></a>
                                <?php if($is_premium): ?><span style="color:var(--pink);font-size:11px;margin-left:5px;">✨ Bloom</span><?php endif; ?>
                                <?php if(!empty($c['user_rating'])): ?>
                                    <span class="user-rate-badge"><?= $c['user_rating'] ?> ★</span>
                                <?php endif; ?>
                            </span>
                            <span class="comment-time"><?= date('M d, Y', strtotime($c['created_at'])) ?></span>
                        </div>
                        <p class="comment-text" id="ctext-<?= (int)$c['id'] ?>"><?= nl2br(htmlspecialchars($c['content'])) ?><?php if(!empty($c['edited_at'])): ?> <span style="color:var(--text-3);font-size:11px;">(edited)</span><?php endif; ?></p>

                        <?php $can_edit = isLoggedIn() && (int)$c['user_id'] === currentUserId();
                              $can_del  = $can_edit || isAdmin(); ?>
                        <?php if($can_edit): ?>
                        <form method="POST" id="cedit-<?= (int)$c['id'] ?>" style="display:none;margin-top:8px;">
                            <input type="hidden" name="comment_id" value="<?= (int)$c['id'] ?>">
                            <textarea name="content" required maxlength="1000" class="form-textarea" style="margin-bottom:8px;"><?= htmlspecialchars($c['content']) ?></textarea>
                            <button type="submit" name="edit_comment" value="1" class="btn-pink" style="padding:6px 16px;font-size:12px;">Save</button>
                            <button type="button" onclick="toggleEdit(<?= (int)$c['id'] ?>)" style="background:none;border:none;color:var(--text-3);cursor:pointer;font-size:12px;">Cancel</button>
                        </form>
                        <?php endif; ?>
                        <?php if($can_del): ?>
                        <div style="display:flex;gap:14px;margin-top:8px;font-size:12px;">
                            <?php if($can_edit): ?>
                            <button type="button" onclick="toggleEdit(<?= (int)$c['id'] ?>)" style="background:none;border:none;color:var(--text-3);cursor:pointer;padding:0;font-size:12px;"><i class="fa-regular fa-pen-to-square"></i> Edit</button>
                            <?php endif; ?>
                            <form method="POST" style="margin:0;" onsubmit="return confirm('Delete this comment?');">
                                <input type="hidden" name="comment_id" value="<?= (int)$c['id'] ?>">
                                <button type="submit" name="delete_comment" value="1" style="background:none;border:none;color:#ef4444;cursor:pointer;padding:0;font-size:12px;"><i class="fa-regular fa-trash-can"></i> Delete</button>
                            </form>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
function toggleEdit(id) {
    const f = document.getElementById('cedit-' + id);
    const t = document.getElementById('ctext-' + id);
    if (!f) return;
    const open = f.style.display !== 'none';
    f.style.display = open ? 'none' : 'block';
    t.style.display = open ? '' : 'none';
}
function toggleDesc() {
    const s = document.getElementById('desc-short');
    const f = document.getElementById('desc-full');
    const b = document.getElementById('desc-toggle');
    const showing = f.style.display !== 'none';
    s.style.display = showing ? '' : 'none';
    f.style.display = showing ? 'none' : '';
    b.textContent = showing ? 'Show more ▼' : 'Show less ▲';
}
</script>

<?php require_once '../includes/footer.php'; ?>
