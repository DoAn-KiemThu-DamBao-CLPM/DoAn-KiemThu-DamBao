<?php
require_once '../config/database.php';
require_once '../includes/auth_ui.php';

if (isLoggedIn()) {
    header('Location: profile.php');
    exit;
}

$sent      = false;
$error     = '';
$dev_link  = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email = mb_strtolower(trim($_POST['email'] ?? ''));

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (loginIsThrottled($pdo, 'reset:' . $email)) {
        $error = 'Too many requests. Please try again in ' . LOGIN_WINDOW_MIN . ' minutes.';
    } else {
        // Count every request (found or not) so the form cannot be used to spam an inbox
        loginRecordFailure($pdo, 'reset:' . $email);

        $st = $pdo->prepare('SELECT id, username FROM users WHERE email = ?');
        $st->execute([$email]);
        $user = $st->fetch();

        if ($user) {
            $token = bin2hex(random_bytes(32));
            $hash  = hash('sha256', $token);

            $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$user['id']]);
            $pdo->prepare('INSERT INTO password_resets (user_id, token_hash, expires_at) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))')
                ->execute([$user['id'], $hash]);

            $link = appBaseUrl() . '/reset_password.php?token=' . $token;
            $body = "Hi " . $user['username'] . ",\r\n\r\n"
                  . "Use the link below to choose a new password (valid for 30 minutes):\r\n$link\r\n\r\n"
                  . "If you did not request this, you can ignore this e-mail.";
            $mailed = @mail($email, 'Reset your Anyn password', $body, "Content-Type: text/plain; charset=UTF-8\r\n");

            if (APP_ENV === 'development' && !$mailed) {
                $dev_link = $link;   // XAMPP usually has no mail server
            }
        }
        // Same answer whether or not the account exists (no user enumeration)
        $sent = true;
    }
}

authPageStart('Forgot password', 'Forgot password? 🔑', "Enter your account email and we'll send you a reset link.");
?>
            <?php if ($error): ?>
                <div class="error-box"><i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <?php if ($sent): ?>
                <div class="success-box"><i class="fa-solid fa-circle-check"></i>
                    If that email is registered, a reset link has been sent. It expires in 30 minutes.</div>
                <?php if ($dev_link): ?>
                    <div class="info-box"><i class="fa-solid fa-flask"></i>
                        <span><strong>Dev mode</strong> (no mail server): <a href="<?= htmlspecialchars($dev_link) ?>" style="color:inherit;text-decoration:underline;">open reset link</a></span></div>
                <?php endif; ?>
            <?php else: ?>
            <form method="POST">
                <div class="form-group">
                    <label>Email</label>
                    <div class="input-wrap">
                        <i class="fa-regular fa-envelope icon-l"></i>
                        <input type="email" name="email" placeholder="you@example.com" required maxlength="255"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                    </div>
                </div>
                <?= csrf_field() ?>
                <button type="submit" class="btn-submit">Send reset link</button>
            </form>
            <?php endif; ?>

            <p class="back-row"><a href="login.php"><i class="fa-solid fa-arrow-left"></i> Back to sign in</a></p>
<?php authPageEnd(); ?>
