<?php
$page_title = 'My Profile';
require_once '../config/database.php';

// Ép buộc phải đăng nhập mới được vào trang này
requireLogin('login.php');

$user_id = currentUserId();
$error = '';
$success = '';

// Lấy thông tin user hiện tại
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();

// KIỂM TRA ĐIỀU KIỆN PREMIUM (Nạp >= 10$)
$is_premium = ($user['total_spent'] >= 10);
$spent_amount = floatval($user['total_spent']);
$progress_percent = min(100, ($spent_amount / 10) * 100);

// Danh sách 10 avatar mặc định m chuẩn bị sẵn (Ở đây t dùng tạm link DiceBear)
// Danh sách 10 avatar mặc định do admin (m) chuẩn bị sẵn
$premade_avatars = [
    '/anyn/uploads/avatars/avt_1.jpg',
    '/anyn/uploads/avatars/avt_2.jpg',
    '/anyn/uploads/avatars/avt_3.jpg',
    '/anyn/uploads/avatars/avt_4.jpg',
    '/anyn/uploads/avatars/avt_5.jpg',
    '/anyn/uploads/avatars/avt_6.jpg',
    '/anyn/uploads/avatars/avt_7.jpg',
    '/anyn/uploads/avatars/avt_8.jpg',
    '/anyn/uploads/avatars/avt_9.jpg',
    '/anyn/uploads/avatars/avt_10.jpg'
];

// XỬ LÝ ĐỔI MẬT KHẨU
$pw_error = '';
$pw_success = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['change_password'])) {
    csrf_verify();
    $cur     = $_POST['current_password'] ?? '';
    $new     = $_POST['new_password'] ?? '';
    $confirm = $_POST['new_password_confirm'] ?? '';

    if (!password_verify($cur, $user['password_hash'])) {
        $pw_error = 'Current password is incorrect.';
    } elseif (($e = validatePassword($new)) !== null) {
        $pw_error = $e;
    } elseif ($new !== $confirm) {
        $pw_error = 'New passwords do not match.';
    } elseif (hash_equals($cur, $new)) {
        $pw_error = 'New password must be different from the current one.';
    } else {
        $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?")
            ->execute([password_hash($new, PASSWORD_DEFAULT), $user_id]);
        $pdo->prepare("DELETE FROM password_resets WHERE user_id = ?")->execute([$user_id]);
        session_regenerate_id(true);
        $pw_success = 'Password changed successfully.';
    }
}

// XỬ LÝ LƯU FORM
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !isset($_POST['change_password'])) {
    csrf_verify();
    $new_username = trim($_POST['username'] ?? '');
    $new_bio = clean_text($_POST['bio'] ?? '', 255);
    $avatar_choice = $_POST['avatar_choice'] ?? '';

    // 1. Validate + kiểm tra trùng tên (nếu user có đổi tên)
    if (($e = validateUsername($new_username)) !== null) {
        $error = $e;
    } elseif ($new_username !== $user['username']) {
        $check = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
        $check->execute([$new_username, $user_id]);
        if ($check->rowCount() > 0) {
            $error = "This username is already taken. Please choose another.";
        }
    }

    $new_avatar_url = $user['avatar_url']; // Giữ nguyên mặc định nếu không đổi

    if (empty($error)) {
        // 2. Xử lý Upload Avatar tùy chỉnh (CHỈ DÀNH CHO PREMIUM)
        if (isset($_FILES['custom_avatar']) && $_FILES['custom_avatar']['error'] == 0) {
            if ($is_premium) {
                $valid_ext = validate_image_upload($_FILES['custom_avatar'], 2 * 1024 * 1024); // 2MB

                if (!$valid_ext) {
                    $error = "Invalid file type or too large. Only JPG, PNG, GIF, WEBP under 2MB are allowed.";
                } else {
                    $filename = 'user_' . $user_id . '_' . time() . '.' . $valid_ext;
                    $dest = '../uploads/avatars/' . $filename;

                    if (move_uploaded_file($_FILES['custom_avatar']['tmp_name'], $dest)) {
                        $new_avatar_url = '/anyn/uploads/avatars/' . $filename;
                    } else {
                        $error = "Failed to save uploaded image.";
                    }
                }
            } else {
                $error = "Nice try! You need to spend $10 to upload custom avatars.";
            }
        } 
        // 3. Xử lý nếu chọn 1 trong 10 avatar có sẵn
        elseif (!empty($avatar_choice) && in_array($avatar_choice, $premade_avatars)) {
            $new_avatar_url = $avatar_choice;
        }

        // Cập nhật Database nếu không có lỗi
        if (empty($error)) {
            $pdo->prepare("UPDATE users SET username = ?, avatar_url = ?, bio = ? WHERE id = ?")->execute([$new_username, $new_avatar_url, $new_bio, $user_id]);
            $user['bio'] = $new_bio;
            $_SESSION['username'] = $new_username; // Cập nhật lại session
            $user['username'] = $new_username;
            $user['avatar_url'] = $new_avatar_url;
            $success = "Profile updated successfully!";
        }
    }
}

// Gọi header sau khi xử lý xong logic
require_once '../includes/header.php';

// Xác định avatar hiển thị hiện tại
$display_avatar = !empty($user['avatar_url']) ? htmlspecialchars($user['avatar_url']) : 'https://i.postimg.cc/mZh4H8hC/default-avatar.png';
$avatar_class = $is_premium ? 'profile-avatar premium-glow' : 'profile-avatar';
if (!empty($user['active_avatar_frame'])) {
    $avatar_class .= ' gem-avt-' . preg_replace('/[^a-z0-9_]/', '', $user['active_avatar_frame']);
}
?>

<style>
    .profile-container { display: flex; gap: 40px; margin-bottom: 50px; align-items: flex-start; }
    
    /* Cột Trái: Thông tin */
    .profile-card { background: var(--surface); padding: 40px 30px; border-radius: 20px; box-shadow: var(--shadow-md); text-align: center; flex: 0 0 320px; height: fit-content; min-width: 0; }
    .profile-avatar { width: 150px; height: 150px; border-radius: 50%; object-fit: cover; margin: 0 auto 20px auto; border: 4px solid #fff; box-shadow: 0 5px 15px rgba(0,0,0,0.1); background: var(--pink-soft); }
    .premium-glow { border-color: #ff8fa3; box-shadow: 0 0 20px rgba(255, 143, 163, 0.6); }
    .stat-box { background: var(--bg); padding: 15px; border-radius: 12px; margin-top: 20px; text-align: left; }
    
    /* Cột Phải: Form chỉnh sửa */
    .edit-card { background: var(--surface); padding: 40px; border-radius: 20px; box-shadow: var(--shadow-md); flex-grow: 1; min-width: 0; }
    
    /* Progress Bar */
    .progress-wrapper { background: #eee; border-radius: 20px; height: 10px; width: 100%; margin: 10px 0; overflow: hidden; }
    .progress-bar { background: linear-gradient(90deg, #ffb7c5, #ff8fa3); height: 100%; border-radius: 20px; transition: 0.5s; }
    
    /* Form Inputs */
    .form-group { margin-bottom: 25px; }
    .form-group label { display: block; font-weight: 600; font-size: 14px; margin-bottom: 10px; color: var(--text-2); }
    .form-group input[type="text"] { width: 100%; padding: 12px 20px; border: 1.5px solid var(--border); border-radius: 12px; font-family: inherit; font-size: 15px; outline: none; transition: 0.3s; box-sizing: border-box; }
    .form-group input[type="text"]:focus { border-color: var(--pink); box-shadow: 0 0 0 3px rgba(255, 183, 197, 0.2); }
    
    /* Grid 10 Avatar */
    .avatar-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 15px; margin-top: 10px; }
    .avatar-option { cursor: pointer; position: relative; }
    .avatar-option input[type="radio"] { display: none; }
    .avatar-img { width: 100%; aspect-ratio: 1; border-radius: 50%; object-fit: cover; border: 3px solid transparent; transition: 0.2s; background: var(--bg); }
    .avatar-option input[type="radio"]:checked + .avatar-img { border-color: var(--pink); transform: scale(1.05); box-shadow: 0 5px 15px rgba(255, 183, 197, 0.4); }
    
    /* Khung Upload Custom */
    .upload-box { border: 2px dashed #ccc; padding: 20px; border-radius: 12px; text-align: center; margin-top: 15px; transition: 0.3s; }
    .upload-box.locked { background: #f9f9f9; cursor: not-allowed; opacity: 0.7; }
    .upload-box.unlocked:hover { border-color: var(--pink); background: var(--pink-soft); }
    .file-input { display: none; }
    
    /* Alert */
    .alert { padding: 15px; border-radius: 10px; margin-bottom: 20px; font-size: 14px; font-weight: 500; }
    .alert-error { background: #fef2f2; color: #ef4444; border: 1px solid #fca5a5; }
    .alert-success { background: #f0fdf4; color: #16a34a; border: 1px solid #bbf7d0; }

    @media (max-width: 960px) {
        .profile-container { flex-direction: column; gap: 18px; }
        .profile-card { flex: 1 1 auto; width: 100%; }
    }

    /* Prevent iOS Safari auto-zoom on input focus */
    @media (max-width: 768px) {
        .profile-card { padding: 22px 16px; border-radius: 16px; }
        .edit-card { padding: 22px 16px; border-radius: 16px; }
        .profile-avatar { width: 120px; height: 120px; }
        .avatar-grid { gap: 8px; grid-template-columns: repeat(5, minmax(0, 1fr)); }
        .form-group input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="number"],
        input[type="search"],
        textarea, select {
            font-size: 16px !important;
        }
    }

    @media (max-width: 420px) {
        .avatar-grid { grid-template-columns: repeat(4, 1fr); }
    }
</style>

<div class="profile-container">
    
    <!-- CỘT TRÁI: THÔNG TIN TỔNG QUAN -->
    <div class="profile-card">
        <img src="<?= $display_avatar ?>" class="<?= $avatar_class ?>" alt="User Avatar">
        <h2 style="margin: 0 0 5px 0; color: var(--text);"><?= htmlspecialchars($user['username']) ?></h2>
        <p style="margin: 0; color: var(--text-3); font-size: 14px; word-break: break-word;"><?= htmlspecialchars($user['email']) ?></p>
        
        <?php if($is_premium): ?>
            <div style="display: inline-block; background: #1a1518; color: #ffb7c5; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: bold; margin-top: 15px; border: 1px solid #ff8fa3; box-shadow: 0 0 10px rgba(255,143,163,0.3);">
                🌸 PREMIUM MEMBER
            </div>
        <?php else: ?>
            <div style="display: inline-block; background: #eee; color: #666; padding: 5px 15px; border-radius: 20px; font-size: 12px; font-weight: bold; margin-top: 15px;">
                MEMBER
            </div>
        <?php endif; ?>

        <?php if (!empty($user['bio'])): ?>
            <p style="margin:12px 0 0;color:var(--text-2);font-size:13px;line-height:1.5;word-break:break-word;"><?= htmlspecialchars($user['bio']) ?></p>
        <?php endif; ?>
        <a href="user.php?id=<?= (int)$user_id ?>" style="display:inline-block;margin-top:14px;color:var(--pink-dark);font-weight:700;font-size:13px;">
            <i class="fa-regular fa-id-card"></i> View my public profile
        </a>

        <div class="stat-box">
            <div style="display: flex; justify-content: space-between; gap: 10px; font-size: 13px; font-weight: 600; color: var(--text-2);">
                <span>Total Spent</span>
                <span style="color: var(--pink-dark);">$<?= number_format($spent_amount, 2) ?></span>
            </div>
            
            <?php if(!$is_premium): ?>
                <div class="progress-wrapper">
                    <div class="progress-bar" style="width: <?= $progress_percent ?>%;"></div>
                </div>
                <div style="font-size: 11px; color: var(--text-3); text-align: center; margin-top: 5px; line-height: 1.5;">
                    Spend $<?= number_format(10 - $spent_amount, 2) ?> more to unlock Custom Avatars!
                </div>
            <?php else: ?>
                <div style="font-size: 12px; color: #16a34a; font-weight: 600; margin-top: 10px; text-align: center;">
                    ✨ Custom Avatars Unlocked! ✨
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- CỘT PHẢI: FORM CHỈNH SỬA -->
    <div class="edit-card">
        <h2 style="margin-top: 0; margin-bottom: 25px; border-bottom: 2px solid var(--pink-soft); padding-bottom: 15px;">Edit Profile</h2>
        
        <?php if ($error): ?> <div class="alert alert-error"><?= htmlspecialchars($error) ?></div> <?php endif; ?>
        <?php if ($success): ?> <div class="alert alert-success"><?= htmlspecialchars($success) ?></div> <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            
            <div class="form-group">
                <label>Display Name</label>
                <input type="text" name="username" value="<?= htmlspecialchars($user['username']) ?>" required minlength="3" maxlength="30">
            </div>

            <div class="form-group">
                <label>Bio</label>
                <input type="text" name="bio" maxlength="255" placeholder="Tell the community about yourself"
                       value="<?= htmlspecialchars($user['bio'] ?? '') ?>">
            </div>

            <div class="form-group">
                <label>Choose an Avatar</label>
                <div style="font-size: 12px; color: var(--text-3); margin-bottom: 10px; line-height: 1.5;">Select from our free collection:</div>
                <div class="avatar-grid">
                    <?php foreach($premade_avatars as $avt): ?>
                        <label class="avatar-option">
                            <input type="radio" name="avatar_choice" value="<?= $avt ?>" <?= ($user['avatar_url'] == $avt) ? 'checked' : '' ?>>
                            <img src="<?= $avt ?>" class="avatar-img" alt="Option">
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-group">
                <label>Or Upload Custom Avatar 💎</label>
                
                <?php if($is_premium): ?>
                    <!-- NẾU LÀ PREMIUM -> MỞ KHÓA TẢI ẢNH -->
                    <label class="upload-box unlocked" style="display: block; cursor: pointer;">
                        <input type="file" name="custom_avatar" accept="image/jpeg, image/png, image/gif" class="file-input" id="customFile">
                        <i class="fa-solid fa-cloud-arrow-up" style="font-size: 24px; color: var(--pink); margin-bottom: 10px;"></i>
                        <div style="font-size: 14px; font-weight: 600; color: var(--text-2);" id="fileName">Click to browse your files</div>
                        <div style="font-size: 12px; color: #999; margin-top: 5px; line-height: 1.5;">Max 2MB. JPG, PNG, GIF.</div>
                    </label>
                <?php else: ?>
                    <!-- NẾU CHƯA ĐỦ 10$ -> KHÓA LẠI -->
                    <div class="upload-box locked">
                        <i class="fa-solid fa-lock" style="font-size: 24px; color: #ccc; margin-bottom: 10px;"></i>
                        <div style="font-size: 14px; font-weight: 600; color: var(--text-3);">Custom Upload Locked</div>
                        <div style="font-size: 12px; color: #aaa; margin-top: 5px; line-height: 1.5;">Unlock this feature by reaching $10 total spent.</div>
                    </div>
                <?php endif; ?>
            </div>

            <?= csrf_field() ?>
                    <button type="submit" class="btn-pink" style="padding: 12px 30px; font-size: 16px; width: 100%; justify-content: center;">Save Changes</button>
        </form>
    </div>

</div>

<!-- ĐỔI MẬT KHẨU -->
<div class="edit-card" style="margin-bottom: 50px;">
        <h2 style="margin-top: 0; margin-bottom: 25px; border-bottom: 2px solid var(--pink-soft); padding-bottom: 15px;">Change Password</h2>
        <?php if ($pw_error): ?> <div class="alert alert-error"><?= htmlspecialchars($pw_error) ?></div> <?php endif; ?>
        <?php if ($pw_success): ?> <div class="alert alert-success"><?= htmlspecialchars($pw_success) ?></div> <?php endif; ?>
        <form method="POST" autocomplete="off">
            <div class="form-group">
                <label>Current password</label>
                <input type="password" name="current_password" required autocomplete="current-password">
            </div>
            <div class="form-group">
                <label>New password</label>
                <input type="password" name="new_password" required minlength="8" maxlength="72" autocomplete="new-password" placeholder="Min. 8 chars, letters + numbers">
            </div>
            <div class="form-group">
                <label>Confirm new password</label>
                <input type="password" name="new_password_confirm" required minlength="8" maxlength="72" autocomplete="new-password">
            </div>
            <?= csrf_field() ?>
            <button type="submit" name="change_password" value="1" class="btn-pink" style="padding: 12px 30px; font-size: 16px; width: 100%; justify-content: center;">Update Password</button>
    </form>
</div>

<script>
// Script nhỏ để hiển thị tên file khi user Premium chọn ảnh tải lên
document.addEventListener('DOMContentLoaded', function() {
    const fileInput = document.getElementById('customFile');
    const fileNameDisplay = document.getElementById('fileName');
    
    if(fileInput) {
        fileInput.addEventListener('change', function() {
            if(this.files && this.files.length > 0) {
                fileNameDisplay.textContent = 'Selected: ' + this.files[0].name;
                fileNameDisplay.style.color = '#f28b9d';
            }
        });
    }
});
</script>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form[enctype="multipart/form-data"]');
    if (!form) return;
    form.addEventListener('submit', function() {
        const btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        btn.disabled = true;
        btn.dataset.originalHtml = btn.innerHTML;
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Saving...';
    });
});
</script>

<?php require_once '../includes/footer.php'; ?>