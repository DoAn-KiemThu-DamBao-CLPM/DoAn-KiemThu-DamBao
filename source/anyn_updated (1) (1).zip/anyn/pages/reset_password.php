<?php
require_once '../config/database.php';
require_once '../includes/auth_ui.php';

$token = (string)($_GET['token'] ?? $_POST['token'] ?? '');
$error = '';
$row   = null;

if (preg_match('/^[a-f0-9]{64}$/', $token)) {
    $st = $pdo->prepare(
        'SELECT pr.id, pr.user_id FROM password_resets pr
         WHERE pr.token_hash = ? AND pr.used_at IS NULL AND pr.expires_at > NOW()'
    );
    $st->execute([hash('sha256', $token)]);
    $row = $st->fetch();
}

if ($row && $_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $new     = $_POST['password'] ?? '';
    $confirm = $_POST['password_confirm'] ?? '';

    if (($e = validatePassword($new)) !== null) {
        $error = $e;
    } elseif ($new !== $confirm) {
        $error = 'Passwords do not match.';
    } else {
        $pdo->prepare('UPDATE users SET password_hash = ? WHERE id = ?')
            ->execute([password_hash($new, PASSWORD_DEFAULT), $row['user_id']]);
        $pdo->prepare('DELETE FROM password_resets WHERE user_id = ?')->execute([$row['user_id']]);
        header('Location: login.php?reset=ok');
        exit;
    }
}

authPageStart('Reset password', 'Choose a new password 🔒', 'Pick something you have not used elsewhere.');
?>
            <?php if (!$row): ?>
                <div class="error-box"><i class="fa-solid fa-circle-exclamation"></i>
                    This reset link is invalid or has expired.</div>
                <p class="back-row"><a href="forgot_password.php">Request a new link</a></p>
            <?php else: ?>
                <?php if ($error): ?>
                    <div class="error-box"><i class="fa-solid fa-circle-exclamation"></i> <?= htmlspecialchars($error) ?></div>
                <?php endif; ?>
                <form method="POST">
                    <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                    <div class="form-group">
                        <label>New password</label>
                        <div class="input-wrap">
                            <i class="fa-solid fa-lock icon-l"></i>
                            <input type="password" name="password" required minlength="8" maxlength="72" autocomplete="new-password" placeholder="Min. 8 chars, letters + numbers">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Confirm new password</label>
                        <div class="input-wrap">
                            <i class="fa-solid fa-lock icon-l"></i>
                            <input type="password" name="password_confirm" required minlength="8" maxlength="72" autocomplete="new-password" placeholder="Repeat password">
                        </div>
                    </div>
                    <?= csrf_field() ?>
                    <button type="submit" class="btn-submit">Update password</button>
                </form>
                <p class="back-row"><a href="login.php">Back to sign in</a></p>
            <?php endif; ?>
<?php authPageEnd(); ?>
