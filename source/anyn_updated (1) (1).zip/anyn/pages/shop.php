<?php
$page_title = 'Gem Shop';
require_once '../config/database.php';
require_once '../includes/gems_lib.php';

ensureGemsSchema($pdo);

if (!isset($_SESSION['user_id'])) {
    require_once '../includes/header.php';
    echo "<div style='text-align:center;padding:60px;background:var(--surface);border-radius:var(--radius);'><h3>Sign in required</h3><p style='color:var(--text-3);'><a href='login.php' style='color:var(--pink-dark);font-weight:700;'>Log in</a> to use the Gem Shop.</p></div>";
    require_once '../includes/footer.php';
    exit;
}

$user_id = (int)$_SESSION['user_id'];
$tab = $_GET['tab'] ?? 'missions';
if (!in_array($tab, ['missions', 'shop', 'inventory'], true)) {
    $tab = 'missions';
}

$flash = '';
$flash_type = 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (isset($_POST['daily_checkin'])) {
        $r = tryAwardMission($pdo, $user_id, 'daily_checkin');
        $flash = $r['message'];
        $flash_type = $r['ok'] ? 'success' : 'error';
        $tab = 'missions';
    } elseif (isset($_POST['buy_item'])) {
        $r = purchaseShopItem($pdo, $user_id, $_POST['buy_item'] ?? '');
        $flash = $r['message'];
        $flash_type = $r['ok'] ? 'success' : 'error';
        $tab = 'shop';
    } elseif (isset($_POST['equip_type'])) {
        $r = equipCosmetic($pdo, $user_id, $_POST['equip_type'], $_POST['equip_key'] ?: null);
        $flash = $r['message'];
        $flash_type = $r['ok'] ? 'success' : 'error';
        $tab = 'inventory';
    } elseif (isset($_POST['buy_image_set'])) {
        $itemKey = $_POST['image_set_item'] ?? '';
        $imageUrl = '';

        if (isset($_FILES['image_set_file']) && $_FILES['image_set_file']['error'] == 0) {
            $target_dir = "../uploads/image_sets/";
            if (!file_exists($target_dir)) mkdir($target_dir, 0755, true);

            $valid_ext = validate_image_upload($_FILES['image_set_file'], 10 * 1024 * 1024);
            if ($valid_ext) {
                $new_name = time() . "_imgset_" . bin2hex(random_bytes(6)) . "." . $valid_ext;
                $target_file = $target_dir . $new_name;
                if (move_uploaded_file($_FILES["image_set_file"]["tmp_name"], $target_file)) {
                    $imageUrl = "/anyn/uploads/image_sets/" . $new_name;
                } else {
                    $flash = "Failed to upload image.";
                    $flash_type = 'error';
                }
            } else {
                $flash = "Invalid image format or file too large. Allowed: JPG, PNG, GIF, WEBP (max 10MB).";
                $flash_type = 'error';
            }
        } elseif (!empty($_POST['image_set_url'])) {
            $imageUrl = safe_http_url($_POST['image_set_url']) ?? '';
            if ($imageUrl === '') {
                $flash = "Image link must be a valid http(s) URL.";
                $flash_type = 'error';
            }
        } else {
            $flash = "Please provide an image file or URL.";
            $flash_type = 'error';
        }

        if ($flash === '' && $imageUrl !== '') {
            $r = createImageSetRequest($pdo, $user_id, $itemKey, $imageUrl);
            $flash = $r['message'];
            $flash_type = $r['ok'] ? 'success' : 'error';
            $tab = 'shop';
        }
    }
}

$gems = getUserGems($pdo, $user_id);
$missions = getMissionProgress($pdo, $user_id);
$shop_items = getShopItems($pdo);
$inventory = getUserInventory($pdo, $user_id);
$image_set_requests = getUserImageSetRequests($pdo, $user_id);
$remaining_publish = getRemainingCommissionLimit($pdo, 'commission_publish');
$remaining_unlisted = getRemainingCommissionLimit($pdo, 'commission_unlisted');

$owned_keys = [];
foreach ($inventory as $inv) {
    if ($inv['used_at'] === null) {
        $owned_keys[$inv['item_key']] = true;
    }
}

$u = $pdo->prepare('SELECT active_avatar_frame FROM users WHERE id = ?');
$u->execute([$user_id]);
$user_cos = $u->fetch();

require_once '../includes/header.php';
?>

<style>
    .gems-hero {
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 18px;
        padding: 24px 26px;
        margin-bottom: 24px;
        border-radius: 24px;
        background: linear-gradient(135deg, rgba(255,183,197,.28), rgba(237,233,254,.96));
        border: 1px solid rgba(255,183,197,.75);
        box-shadow: var(--shadow-sm);
    }
    .gems-hero, .mission-card, .shop-item-card { min-width: 0; }
    .gems-balance { font-size: 32px; font-weight: 900; color: var(--pink-dark); display: flex; align-items: center; gap: 10px; white-space: nowrap; }
    .gems-balance i { color: #f472b6; }

    .shop-tabs {
        display: flex;
        gap: 8px;
        margin-bottom: 24px;
        flex-wrap: nowrap;
        overflow-x: auto;
        -webkit-overflow-scrolling: touch;
        padding-bottom: 4px;
    }
    .shop-tab {
        padding: 10px 18px;
        border-radius: 999px;
        font-weight: 800;
        font-size: 13px;
        text-decoration: none;
        border: 1.5px solid var(--border);
        color: var(--text-2);
        background: var(--surface);
        display: inline-flex;
        align-items: center;
        gap: 8px;
        white-space: nowrap;
        box-shadow: var(--shadow-sm);
        transition: transform .2s ease, background .2s ease, border-color .2s ease;
    }
    .shop-tab:hover { transform: translateY(-1px); }
    .shop-tab.active { background: var(--pink-soft); border-color: var(--pink); color: var(--pink-dark); }

    .mission-card, .shop-item-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 20px;
        padding: 18px;
        margin-bottom: 12px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        flex-wrap: wrap;
        box-shadow: var(--shadow-sm);
        transition: transform .2s ease, box-shadow .2s ease, border-color .2s ease;
    }
    .mission-card:hover, .shop-item-card:hover { transform: translateY(-2px); box-shadow: var(--shadow-md); border-color: rgba(255,183,197,.85); }
    .mission-card h4, .shop-item-card h4 { margin: 0 0 4px; font-size: 15px; color: var(--text); }
    .mission-card p, .shop-item-card p { margin: 0; font-size: 12px; color: var(--text-3); }
    .gem-reward { color: #7c3aed; font-weight: 900; font-size: 14px; white-space: nowrap; display: inline-flex; align-items: center; gap: 6px; }
    .progress-bar { height: 8px; background: var(--surface-2); border-radius: 999px; margin-top: 8px; overflow: hidden; max-width: 240px; }
    .progress-bar span { display: block; height: 100%; background: linear-gradient(90deg, var(--pink), #a855f7); border-radius: 999px; }

    .shop-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; }
    .shop-item-card { flex-direction: column; align-items: stretch; }
    .shop-item-card .shop-item-foot { display: flex; justify-content: space-between; align-items: center; margin-top: 12px; width: 100%; gap: 12px; }

    .btn-gem, .btn-checkin, .btn-gem-secondary {
        min-height: 44px;
        padding: 10px 16px;
        border-radius: 12px;
        border: none;
        font-weight: 800;
        font-size: 13px;
        cursor: pointer;
        font-family: inherit;
        transition: transform .2s ease, filter .2s ease, background .2s ease;
    }
    .btn-gem { background: linear-gradient(135deg, #c084fc, #a855f7); color: white; }
    .btn-gem:hover, .btn-checkin:hover { transform: translateY(-1px); filter: brightness(1.03); }
    .btn-gem:disabled { opacity: .5; cursor: not-allowed; transform: none; }
    .btn-gem-secondary { background: var(--surface-2); color: var(--text-2); border: 1px solid var(--border); }
    .btn-checkin { background: linear-gradient(135deg, #10b981, #059669); color: white; }

    .category-title { font-size: 17px; font-weight: 900; color: var(--pink-dark); margin: 24px 0 12px; }
    .inv-item { display: flex; justify-content: space-between; align-items: center; gap: 10px; flex-wrap: wrap; }
    .badge-owned, .badge-used { font-size: 10px; font-weight: 900; padding: 4px 9px; border-radius: 999px; text-transform: uppercase; letter-spacing: .3px; }
    .badge-owned { background: #dcfce7; color: #15803d; }
    .badge-used { background: var(--surface-2); color: var(--text-3); }
    .shop-note { font-size: 13px; color: var(--text-3); line-height: 1.6; margin-bottom: 20px; }

    #image_set_modal { backdrop-filter: blur(6px); }
    #image_set_modal > div {
        background: var(--surface);
        padding: 28px;
        border-radius: 22px;
        max-width: 500px;
        width: min(92vw, 500px);
        max-height: 90vh;
        overflow-y: auto;
        box-shadow: var(--shadow-lg);
        border: 1px solid var(--border);
    }

    @media (max-width: 640px) {
        .gems-hero { padding: 16px; border-radius: 18px; align-items: flex-start; flex-direction: column; }
        .gems-balance { font-size: 24px; width: 100%; justify-content: flex-start; }
        .shop-grid { grid-template-columns: 1fr; gap: 14px; }
        .shop-tab { padding: 8px 14px; font-size: 13px; flex: 0 0 auto; }
        .mission-card, .shop-item-card { padding: 14px; }
        .shop-item-card .shop-item-foot, .inv-item { flex-direction: column; align-items: stretch; }
        .btn-gem, .btn-checkin, .btn-gem-secondary { width: 100%; }
        .progress-bar { max-width: 100%; }
        .category-title { margin-top: 18px; }
        #image_set_modal > div { padding: 20px 16px; border-radius: 18px; }
        #image_set_modal form > div:last-child { flex-direction: column; }
    }
</style>

<div class="gems-hero animate-in">
    <div>
        <h2 class="section-title" style="margin:0 0 6px;">Gem Shop & Missions</h2>
        <p style="margin:0;color:var(--text-2);font-size:14px;">Earn gems from activity, spend them on cosmetics &amp; rewards.</p>
    </div>
    <div class="gems-balance"><i class="fa-solid fa-gem"></i> <?= number_format($gems) ?> gems</div>
</div>

<?php if ($flash): ?>
<div class="alert-<?= $flash_type === 'success' ? 'success' : 'error' ?>" style="padding:12px 16px;border-radius:10px;margin-bottom:20px;font-weight:600;background:<?= $flash_type === 'success' ? '#f0fdf4;color:#16a34a' : '#fef2f2;color:#ef4444' ?>;">
    <?= htmlspecialchars($flash) ?>
</div>
<?php endif; ?>

<div class="shop-tabs" id="shopTabs">
    <a href="?tab=missions" class="shop-tab <?= $tab === 'missions' ? 'active' : '' ?>"><i class="fa-solid fa-list-check"></i> Missions</a>
    <a href="?tab=shop" class="shop-tab <?= $tab === 'shop' ? 'active' : '' ?>"><i class="fa-solid fa-store"></i> Shop</a>
    <a href="?tab=inventory" class="shop-tab <?= $tab === 'inventory' ? 'active' : '' ?>"><i class="fa-solid fa-box-open"></i> Inventory</a>
</div>

<?php if ($tab === 'missions'): ?>
    <p class="shop-note">Complete daily missions to earn gems. Limits reset at midnight.</p>

    <form method="POST" style="margin-bottom:24px;">
        <?= csrf_field() ?>
        <button type="submit" name="daily_checkin" class="btn-checkin" <?= $missions['daily_checkin']['done'] >= 1 ? 'disabled' : '' ?>>
            <i class="fa-solid fa-calendar-check"></i>
            <?= $missions['daily_checkin']['done'] >= 1 ? 'Checked in today' : 'Daily check-in (+5 gems)' ?>
        </button>
    </form>

    <?php foreach ($missions as $key => $m):
        if ($key === 'daily_checkin') continue;
        $pct = $m['daily_max'] > 0 ? min(100, ($m['done'] / $m['daily_max']) * 100) : 0;
    ?>
    <div class="mission-card">
        <div style="flex:1;min-width:0;">
            <h4><?= htmlspecialchars($m['name']) ?></h4>
            <p><?= (int)$m['done'] ?> / <?= (int)$m['daily_max'] ?> today</p>
            <div class="progress-bar"><span style="width:<?= $pct ?>%"></span></div>
        </div>
        <span class="gem-reward">+<?= (int)$m['gems'] ?> <i class="fa-solid fa-gem"></i> / each</span>
    </div>
    <?php endforeach; ?>

<?php elseif ($tab === 'shop'): ?>
    <p class="shop-note">30 gems ≈ $3 value for image sets. Commission vouchers are used when placing an order. Avatar frames equip automatically on purchase.</p>

    <?php
    $by_cat = [];
    foreach ($shop_items as $si) {
        $by_cat[$si['category']][] = $si;
    }
    foreach ($by_cat as $cat => $items):
    ?>
        <?php if ($cat === 'image_set'): ?>
            <h3 class="category-title"><?= htmlspecialchars(shopCategoryLabel($cat)) ?></h3>
            <p class="shop-note" style="margin-bottom:15px;">Select a character image set tier and upload an image of the character set you want. Admin will send you the link after purchase.</p>
            <div class="shop-grid">
                <?php foreach ($items as $si):
                    $can_afford = $gems >= (int)$si['cost_gems'];
                ?>
                <div class="shop-item-card">
                    <h4><?= htmlspecialchars($si['name']) ?></h4>
                    <p><?= htmlspecialchars($si['description'] ?? '') ?></p>
                    <div class="shop-item-foot">
                        <span class="gem-reward"><?= (int)$si['cost_gems'] ?> <i class="fa-solid fa-gem"></i></span>
                        <button type="button" class="btn-gem" <?= !$can_afford ? 'disabled' : '' ?> onclick="showImageSetForm('<?= htmlspecialchars($si['item_key']) ?>', <?= (int)$si['cost_gems'] ?>)">Select</button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div id="image_set_modal" style="display:none;position:fixed;inset:0;background:rgba(0,0,0,0.5);z-index:1000;align-items:center;justify-content:center;padding:20px;">
                <div>
                    <h3 style="margin:0 0 20px;color:var(--pink-dark);">Purchase Image Set</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="image_set_item" id="modal_item_key">
                        <div class="form-group">
                            <label>Price Tier</label>
                            <div id="modal_price" style="font-size:18px;font-weight:bold;color:var(--pink-dark);margin-bottom:15px;"></div>
                        </div>
                        <div class="form-group">
                            <label>Upload Character Image</label>
                            <input type="file" name="image_set_file" accept="image/*" style="width:100%;padding:10px;border:1.5px solid var(--border);border-radius:10px;">
                        </div>
                        <div style="text-align:center;color:var(--text-3);font-size:12px;margin:10px 0;">— OR —</div>
                        <div class="form-group">
                            <label>Or Paste Image URL</label>
                            <input type="text" name="image_set_url" placeholder="https://..." style="width:100%;padding:10px;border:1.5px solid var(--border);border-radius:10px;">
                        </div>
                        <div style="display:flex;gap:10px;margin-top:20px;">
                            <button type="submit" name="buy_image_set" class="btn-submit" style="flex:1;">Purchase</button>
                            <button type="button" onclick="hideImageSetForm()" style="flex:1;padding:12px;border:none;border-radius:12px;background:var(--surface-2);color:var(--text-2);font-weight:bold;cursor:pointer;">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>

            <script>
            function showImageSetForm(itemKey, price) {
                document.getElementById('modal_item_key').value = itemKey;
                document.getElementById('modal_price').textContent = price + ' gems';
                document.getElementById('image_set_modal').style.display = 'flex';
            }
            function hideImageSetForm() {
                document.getElementById('image_set_modal').style.display = 'none';
            }
            document.getElementById('image_set_modal')?.addEventListener('click', function(e) {
                if (e.target === this) hideImageSetForm();
            });
            </script>

            <?php if (!empty($image_set_requests)): ?>
            <h3 class="category-title" style="margin-top:30px;">Your Image Set Requests</h3>
            <?php foreach ($image_set_requests as $req): ?>
            <div class="mission-card">
                <div style="flex:1;min-width:0;">
                    <h4><?= htmlspecialchars($req['item_name']) ?> - <?= (int)$req['cost_gems'] ?> gems</h4>
                    <p>Status: <strong style="color:<?= $req['status'] === 'completed' ? '#10b981' : '#f59e0b' ?>;"> <?= ucfirst($req['status']) ?></strong></p>
                    <?php if ($req['admin_link']): ?>
                    <p style="margin-top:5px;"><a href="<?= htmlspecialchars($req['admin_link']) ?>" target="_blank" style="color:var(--pink-dark);font-weight:bold;">View Image Set</a></p>
                    <?php endif; ?>
                </div>
                <span style="font-size:12px;color:var(--text-3);white-space:nowrap;"><?= date('M j, Y', strtotime($req['created_at'])) ?></span>
            </div>
            <?php endforeach; ?>
            <?php endif; ?>
        <?php else: ?>
            <h3 class="category-title"><?= htmlspecialchars(shopCategoryLabel($cat)) ?></h3>
            <div class="shop-grid">
                <?php foreach ($items as $si):
                    $owned = isset($owned_keys[$si['item_key']]) && $cat === 'avatar_frame';
                    $can_afford = $gems >= (int)$si['cost_gems'];
                    $remaining = 0;
                    if ($si['category'] === 'commission_publish') {
                        $remaining = $remaining_publish;
                    } elseif ($si['category'] === 'commission_unlisted') {
                        $remaining = $remaining_unlisted;
                    }
                ?>
                <div class="shop-item-card">
                    <h4><?= htmlspecialchars($si['name']) ?></h4>
                    <p><?= htmlspecialchars($si['description'] ?? '') ?></p>
                    <?php if ($si['category'] === 'commission_publish' || $si['category'] === 'commission_unlisted'): ?>
                    <p style="font-size:12px;color:var(--text-3);">Remaining this month: <strong style="color:<?= $remaining > 0 ? '#10b981' : '#ef4444' ?>;"> <?= $remaining ?></strong></p>
                    <?php endif; ?>
                    <div class="shop-item-foot">
                        <span class="gem-reward"><?= (int)$si['cost_gems'] ?> <i class="fa-solid fa-gem"></i></span>
                        <?php if ($owned): ?>
                            <span class="badge-owned">Owned</span>
                        <?php elseif ($si['category'] === 'commission_publish' || $si['category'] === 'commission_unlisted'): ?>
                            <?php if ($remaining > 0): ?>
                                <form method="POST" style="margin:0;">
                                    <input type="hidden" name="buy_item" value="<?= htmlspecialchars($si['item_key']) ?>">
                                    <button type="submit" class="btn-gem" <?= !$can_afford ? 'disabled' : '' ?>>Buy</button>
                                </form>
                            <?php else: ?>
                                <span class="badge-used">Sold out</span>
                            <?php endif; ?>
                        <?php else: ?>
                            <form method="POST" style="margin:0;">
                                <input type="hidden" name="buy_item" value="<?= htmlspecialchars($si['item_key']) ?>">
                                <button type="submit" class="btn-gem" <?= !$can_afford ? 'disabled' : '' ?>>Buy</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    <?php endforeach; ?>

<?php else: ?>
    <p class="shop-note">Equip avatar frames. Use commission vouchers on the <a href="commission.php" style="color:var(--pink-dark);font-weight:700;">Commission</a> page.</p>

    <h3 class="category-title">Equipped</h3>
    <div class="mission-card">
        <div>
            <h4>Avatar frame</h4>
            <p><?= htmlspecialchars($user_cos['active_avatar_frame'] ?: 'None') ?></p>
        </div>
        <form method="POST" style="display:flex;gap:6px;flex-wrap:wrap;">
            <input type="hidden" name="equip_type" value="avatar_frame">
            <select name="equip_key" class="form-input" style="margin:0;max-width:180px;padding:8px;">
                <option value="">— None —</option>
                <?php foreach ($inventory as $inv):
                    if ($inv['item_type'] !== 'avatar_frame' || $inv['used_at']) continue;
                ?>
                <option value="<?= htmlspecialchars($inv['item_key']) ?>" <?= $user_cos['active_avatar_frame'] === $inv['item_key'] ? 'selected' : '' ?>><?= htmlspecialchars($inv['name'] ?? $inv['item_key']) ?></option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn-gem btn-gem-secondary">Equip</button>
        </form>
    </div>

    <h3 class="category-title">All items</h3>
    <?php if (empty($inventory)): ?>
        <p style="color:var(--text-3);">Your inventory is empty. Visit the Shop!</p>
    <?php else: ?>
        <?php foreach ($inventory as $inv): ?>
        <div class="mission-card inv-item">
            <div>
                <h4><?= htmlspecialchars($inv['name'] ?? $inv['item_key']) ?></h4>
                <p><?= htmlspecialchars(shopCategoryLabel($inv['item_type'])) ?></p>
            </div>
            <?php if ($inv['used_at']): ?>
                <span class="badge-used">Used</span>
            <?php else: ?>
                <span class="badge-owned">Available</span>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    <?php endif; ?>
<?php endif; ?>

<script>
(function () {
    const forms = document.querySelectorAll('form');
    forms.forEach((form) => {
        const btn = form.querySelector('button[type="submit"]');
        if (!btn) return;
        form.addEventListener('submit', () => {
            btn.disabled = true;
            btn.dataset.originalHtml = btn.innerHTML;
            btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Working...';
        });
    });
})();
</script>

<?php require_once '../includes/footer.php'; ?>