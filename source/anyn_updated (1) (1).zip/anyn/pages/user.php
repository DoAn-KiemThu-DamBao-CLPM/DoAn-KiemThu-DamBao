<?php
$page_title = 'Member Profile';
require_once '../config/database.php';
require_once '../includes/community_gallery_lib.php';

ensureCommunityGallerySchema($pdo);

$profile_id = (int)($_GET['id'] ?? 0);
$st = $pdo->prepare('SELECT id, username, avatar_url, bio, role, created_at FROM users WHERE id = ?');
$st->execute([$profile_id]);
$member = $st->fetch();

if (!$member) {
    http_response_code(404);
    require_once '../includes/header.php';
    echo "<div style='text-align:center;padding:80px 20px;color:var(--text-3);'><p>Member not found.</p></div>";
    require_once '../includes/footer.php';
    exit;
}

$me       = currentUserId();
$is_self  = ($me === (int)$member['id']);
$flash    = '';

// ---- Follow / Unfollow ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['follow_action'])) {
    csrf_verify();
    requireLogin('login.php');
    if (!$is_self) {
        if ($_POST['follow_action'] === 'follow') {
            $pdo->prepare('INSERT IGNORE INTO user_follows (follower_id, following_id) VALUES (?, ?)')
                ->execute([$me, $member['id']]);
        } elseif ($_POST['follow_action'] === 'unfollow') {
            $pdo->prepare('DELETE FROM user_follows WHERE follower_id = ? AND following_id = ?')
                ->execute([$me, $member['id']]);
        }
    }
    header('Location: user.php?id=' . (int)$member['id']);
    exit;
}

// ---- Owner deletes their own community post ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_post_id'])) {
    csrf_verify();
    requireLogin('login.php');
    $pid = (int)$_POST['delete_post_id'];
    $own = $pdo->prepare('SELECT id, image_url FROM community_posts WHERE id = ? AND user_id = ?');
    $own->execute([$pid, $me]);
    if ($post = $own->fetch()) {
        $pdo->prepare('DELETE FROM community_reactions WHERE post_id = ?')->execute([$pid]);
        $pdo->prepare('DELETE FROM community_posts WHERE id = ?')->execute([$pid]);
        $file = __DIR__ . '/../uploads/community/' . basename((string)$post['image_url']);
        if (is_file($file)) {
            @unlink($file);
        }
        $flash = 'Your post was deleted.';
    }
}

$cnt = function (string $sql, array $p) use ($pdo): int {
    $s = $pdo->prepare($sql);
    $s->execute($p);
    return (int)$s->fetchColumn();
};
$followers = $cnt('SELECT COUNT(*) FROM user_follows WHERE following_id = ?', [$member['id']]);
$following = $cnt('SELECT COUNT(*) FROM user_follows WHERE follower_id = ?', [$member['id']]);
$is_following = $me && !$is_self
    ? $cnt('SELECT COUNT(*) FROM user_follows WHERE follower_id = ? AND following_id = ?', [$me, $member['id']]) > 0
    : false;

$posts_sql = 'SELECT * FROM community_posts WHERE user_id = ? ' . ($is_self ? '' : "AND status = 'approved' ") . 'ORDER BY created_at DESC LIMIT 24';
$ps = $pdo->prepare($posts_sql);
$ps->execute([$member['id']]);
$posts = $ps->fetchAll();

$cs = $pdo->prepare(
    'SELECT c.content, c.created_at, b.id AS bot_id, b.name AS bot_name
     FROM comments c JOIN bots b ON b.id = c.bot_id
     WHERE c.user_id = ? ORDER BY c.created_at DESC LIMIT 10'
);
$cs->execute([$member['id']]);
$recent_comments = $cs->fetchAll();

$avatar = !empty($member['avatar_url']) ? $member['avatar_url'] : 'https://i.postimg.cc/mZh4H8hC/default-avatar.png';
$page_title = $member['username'];
require_once '../includes/header.php';
?>
<style>
    .mp-head { display:flex; gap:24px; align-items:center; background:var(--surface); border:1px solid var(--border); border-radius:20px; padding:26px; margin-bottom:24px; flex-wrap:wrap; }
    .mp-avatar { width:110px; height:110px; border-radius:50%; object-fit:cover; border:3px solid var(--pink); }
    .mp-name { font-size:26px; margin:0 0 4px; color:var(--text); }
    .mp-bio { color:var(--text-2); font-size:14px; margin:8px 0 12px; word-break:break-word; max-width:520px; }
    .mp-stats { display:flex; gap:22px; font-size:13px; color:var(--text-3); margin-bottom:14px; }
    .mp-stats strong { color:var(--text); font-size:16px; display:block; }
    .mp-badge { display:inline-block; background:var(--pink-soft); color:var(--pink-dark); font-size:11px; font-weight:800; padding:3px 10px; border-radius:20px; margin-left:8px; vertical-align:middle; }
    .mp-section { margin-bottom:30px; }
    .mp-section h3 { color:var(--text); border-left:4px solid var(--pink); padding-left:10px; margin:0 0 14px; font-size:18px; }
    .mp-grid { display:grid; grid-template-columns:repeat(auto-fill,minmax(160px,1fr)); gap:14px; }
    .mp-post { background:var(--surface); border:1px solid var(--border); border-radius:14px; overflow:hidden; font-size:12px; color:var(--text-2); }
    .mp-post img { width:100%; aspect-ratio:1/1; object-fit:cover; display:block; }
    .mp-post .meta { padding:8px 10px; display:flex; justify-content:space-between; align-items:center; gap:6px; }
    .mp-status { font-weight:700; text-transform:capitalize; }
    .mp-status.pending { color:#d97706; } .mp-status.approved { color:#16a34a; } .mp-status.rejected { color:#dc2626; }
    .mp-del { background:none; border:none; color:#ef4444; cursor:pointer; font-size:12px; font-weight:700; }
    .mp-comment { background:var(--surface); border:1px solid var(--border); border-radius:12px; padding:12px 14px; margin-bottom:10px; font-size:13px; color:var(--text-2); }
    .mp-comment a { color:var(--pink-dark); font-weight:700; }
    .mp-flash { background:#f0fdf4; color:#16a34a; padding:10px 14px; border-radius:10px; margin-bottom:16px; font-size:13px; font-weight:600; }
</style>

<?php if ($flash): ?><div class="mp-flash"><?= htmlspecialchars($flash) ?></div><?php endif; ?>

<div class="mp-head animate-in">
    <img class="mp-avatar" src="<?= htmlspecialchars($avatar) ?>" alt="">
    <div>
        <h1 class="mp-name"><?= htmlspecialchars($member['username']) ?>
            <?php if ($member['role'] === 'admin'): ?><span class="mp-badge">ADMIN</span><?php endif; ?></h1>
        <div style="color:var(--text-3);font-size:12px;">Joined <?= date('M Y', strtotime($member['created_at'])) ?></div>
        <?php if (!empty($member['bio'])): ?><p class="mp-bio"><?= nl2br(htmlspecialchars($member['bio'])) ?></p><?php endif; ?>
        <div class="mp-stats">
            <div><strong><?= $followers ?></strong>Followers</div>
            <div><strong><?= $following ?></strong>Following</div>
        </div>
        <?php if ($is_self): ?>
            <a class="btn-pink" href="profile.php">Edit profile</a>
        <?php elseif (isLoggedIn()): ?>
            <form method="POST" style="margin:0;">
                <input type="hidden" name="follow_action" value="<?= $is_following ? 'unfollow' : 'follow' ?>">
                <button type="submit" class="btn-pink"><?= $is_following ? 'Unfollow' : 'Follow' ?></button>
            </form>
        <?php else: ?>
            <a class="btn-pink" href="login.php">Sign in to follow</a>
        <?php endif; ?>
    </div>
</div>

<div class="mp-section">
    <h3>Community artwork</h3>
    <?php if (!$posts): ?>
        <p style="color:var(--text-3);font-size:14px;">No artwork yet.</p>
    <?php else: ?>
    <div class="mp-grid">
        <?php foreach ($posts as $p): ?>
        <div class="mp-post">
            <img src="<?= htmlspecialchars($p['image_url']) ?>" alt="<?= htmlspecialchars($p['title'] ?? 'Artwork') ?>" loading="lazy">
            <div class="meta">
                <span><?= htmlspecialchars($p['title'] ?? 'Untitled') ?></span>
                <?php if ($is_self): ?>
                    <span class="mp-status <?= htmlspecialchars($p['status']) ?>"><?= htmlspecialchars($p['status']) ?></span>
                <?php endif; ?>
            </div>
            <?php if ($is_self): ?>
            <form method="POST" class="meta" style="padding-top:0;" onsubmit="return confirm('Delete this post permanently?');">
                <input type="hidden" name="delete_post_id" value="<?= (int)$p['id'] ?>">
                <button type="submit" class="mp-del"><i class="fa-regular fa-trash-can"></i> Delete</button>
            </form>
            <?php endif; ?>
        </div>
        <?php endforeach; ?>
    </div>
    <?php endif; ?>
</div>

<div class="mp-section">
    <h3>Recent comments</h3>
    <?php if (!$recent_comments): ?>
        <p style="color:var(--text-3);font-size:14px;">No comments yet.</p>
    <?php endif; ?>
    <?php foreach ($recent_comments as $c): ?>
        <div class="mp-comment">
            On <a href="bot_detail.php?id=<?= (int)$c['bot_id'] ?>"><?= htmlspecialchars($c['bot_name']) ?></a>
            · <span style="color:var(--text-3);"><?= date('M d, Y', strtotime($c['created_at'])) ?></span>
            <div style="margin-top:6px;"><?= nl2br(htmlspecialchars($c['content'])) ?></div>
        </div>
    <?php endforeach; ?>
</div>

<?php require_once '../includes/footer.php'; ?>
