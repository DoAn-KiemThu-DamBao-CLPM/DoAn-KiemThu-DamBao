<?php
require_once 'config/database.php';

header('Content-Type: application/json; charset=utf-8');

$q = clean_text($_GET['q'] ?? '', 60);

if ($q === '') {
    echo json_encode([]);
    exit;
}

// Prepared statement + escaped wildcards: user input can never alter the query
$stmt = $pdo->prepare("SELECT id, name, image_url FROM bots WHERE name LIKE ? LIMIT 5");
$stmt->execute(['%' . like_escape($q) . '%']);

echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC), JSON_UNESCAPED_UNICODE);
