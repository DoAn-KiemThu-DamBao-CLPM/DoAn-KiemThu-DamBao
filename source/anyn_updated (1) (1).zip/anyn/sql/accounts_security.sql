-- ANYN: accounts / security update.  (The site also applies this automatically on first request;
-- run it by hand in phpMyAdmin only if you prefer.)

-- 1. Roles (Guest = not logged in, User, Admin)
ALTER TABLE users ADD COLUMN role ENUM('user','admin') NOT NULL DEFAULT 'user';
UPDATE users SET role = 'admin' WHERE id = 1;

-- 2. Profile bio
ALTER TABLE users ADD COLUMN bio VARCHAR(255) NULL;

-- 3. Unique username / email
ALTER TABLE users ADD UNIQUE KEY uq_users_username (username);
ALTER TABLE users ADD UNIQUE KEY uq_users_email (email);

-- 4. Comment edit marker
ALTER TABLE comments ADD COLUMN edited_at TIMESTAMP NULL DEFAULT NULL;

-- 5. Forgot password (only the SHA-256 hash of the token is stored)
CREATE TABLE IF NOT EXISTS password_resets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT(11) NOT NULL,
    token_hash CHAR(64) NOT NULL,
    expires_at DATETIME NOT NULL,
    used_at DATETIME NULL DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_reset_token (token_hash),
    INDEX idx_reset_user (user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. Brute-force protection
CREATE TABLE IF NOT EXISTS login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(45) NOT NULL,
    email VARCHAR(255) NOT NULL,
    attempted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_la_ip (ip, attempted_at),
    INDEX idx_la_email (email, attempted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. Follow users
CREATE TABLE IF NOT EXISTS user_follows (
    follower_id INT(11) NOT NULL,
    following_id INT(11) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (follower_id, following_id),
    INDEX idx_follow_following (following_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. Content policy: remove NSFW tags (netori, cheating, ...)
DELETE bt FROM bot_themes bt JOIN themes t ON t.id = bt.theme_id
 WHERE LOWER(REPLACE(REPLACE(t.name,'-',''),' ','')) IN
 ('netori','netorare','netora','ntr','cheating','cheater','cheat','cuck','cuckold','infidelity','adultery',
  'nsfw','r18','r18g','18','hentai','smut','lewd','erotic','erotica','porn','sex','sexual','bdsm','fetish',
  'rape','noncon','dubcon','cnc','consensualnonconsent','stepfamily','incest','loli','shota');
DELETE FROM themes
 WHERE LOWER(REPLACE(REPLACE(name,'-',''),' ','')) IN
 ('netori','netorare','netora','ntr','cheating','cheater','cheat','cuck','cuckold','infidelity','adultery',
  'nsfw','r18','r18g','18','hentai','smut','lewd','erotic','erotica','porn','sex','sexual','bdsm','fetish',
  'rape','noncon','dubcon','cnc','consensualnonconsent','stepfamily','incest','loli','shota');
